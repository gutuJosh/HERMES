##WHAT IS AND HOW IT WORKS?
This is a web tool created for Neosoft s.r.l
It allows Neosoft employee's to compose, view and send html email messages based on premade templates and serve the
need to communicate with Bancomail's(e-commerce website) various type of clients in various scenarios.

The app use React js on the client and Express js on the server side.

Users can select or modify preloaded templates and/or components (code snippets) like widgets, tables, etc,
or can choose to create new components by inserting custom html code from a control panel.

Every template has somme meta-data associated such as email subject, sender info, signature, other html components to load, etc., 
which are stored in json files (located in config folder) and are configurable from a dedicated control panel within the app.

Templates contain various dynamic fields enclosed in square brackets that accept values passed in get method.

Example: /?type=prev_nu&contatto=Cosmin%20Horvath&ragione_sociale=My%20company&to=cosmin.horvath@bancomail.it&widgets=widget-welcome-coupon

The above url instruct the app to automatically load the template used in case of a response to a quote request. After that the app will populate the fileds "[contatto]" which stand for "contact name" and "[ragione_sociale]" which stand for "company name", then will include the widget "welcome coupon" and finally set the recipent to "cosmin.horvath@bancomail.it"



##INSTALL

First go to the client folder and install node dependency, then run build

cd email-management/client
npm install
npm run build

then go back on root folder
npm install
npm start


The app wil start on port 5000

To actually send an email you have to set your smtp server details or your gmail account
in root/config/smtp.json

PS: Please destroy all the files after you done.




