import React from 'react';
import Preloader from './components/Preloader';
import AppStore from './stores/AppStore.js';
import axios from 'axios';

export default class TemplateEditor extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           action: null,
           template: {action:'',component:'',template:''},
           html:'',
           showPreloader: 'show',
           serverResponse: {status:null, message:null}
        }
        this._onPreload = this._onPreload.bind(this);
   
    }

    componentWillMount(){
        AppStore.addChangeListener(this._onPreload);
        this._onPreload();
    }

    componentWillUnmount() {
        AppStore.removeChangeListener(this._onPreload);
    }

    _onPreload(){
        this.setState({template: AppStore.getTemplateEditor()});
    }

    componentDidMount(){
        
        if(this.state.template.action === 'modify'){
            var self = this;
            fetch('/templatemanager/readfile/'+this.state.template.component+'/'+this.state.template.template.replace('.html','')+'/?language='+encodeURIComponent(this.props.returnComponentState('language')))
            .then(function(response){
                response.json().then(function(data) {
                if(data[0].status === 200){
                    self.setState({showPreloader:'hidden','html':data[0].content.content});
                    let updateTemplatePreviewer = {'templateBody': data[0].content.content}
                    self.props.handleState(updateTemplatePreviewer, false);
                }
                else{
                    console.log(data[0].content);
                }
            });
        });
       }
       else{
           let cmp = this.state.template.component;
           let tmp = this.state.template.template.replace('.html','') + '.html';
           this.setState({showPreloader:'hidden', template: {action:'new',component: cmp, template: tmp}});
       }

    }

    onChangeFunction(component, value){
        this.setState({html:value});
    }

    updateTemplatePreviewer(event){
        let updateTemplatePreviewer = {'templateBody': event.target.value}
        this.props.handleState(updateTemplatePreviewer, false);
    }

    saveChanges(event){
         event.preventDefault();
         let tmp = this.props.returnComponentState('templateBody');
         if(tmp === ''){
            return false;
         }
         
        var self = this;
        this.setState({showPreloader:'show'});
        axios.post('/templatemanager/edit/'+encodeURIComponent(this.state.template.action)+'/'+encodeURIComponent(this.state.template.component)+'/'+encodeURIComponent(this.state.template.template),
                {
                message: encodeURIComponent(tmp),
                language: encodeURIComponent(this.props.returnComponentState('language'))
                }
        ).then(function (response) {
            self.setState({showPreloader:'hidden'});
            self.setState({serverResponse: {status:response.data[0].status, message:response.data[0].message}});

        }).catch(function (error) {
            self.setState({showPreloader:'hidden'});
            alert(error);
            
        });
         
    }
    
    resetServerResponse(event){
        event.preventDefault();
        this.setState({serverResponse: {status:null, message:null}});
    }

    goBack(event){
        event.preventDefault();
        var component = event.target.value !== undefined ? event.target.value : event.target.parentNode.value;
        let updateTemplatePreviewer = {'templateBody': ''};
        this.props.handleState(updateTemplatePreviewer, false);
        this.props.handleState('activeComponent', component);
    }

 
    render() {
        
        return (
          <div id="draftContentEditor" className="flex-item template-settings">
          
           <div className="template-mofidier-holder">
            <div className="row">
                <div className="col-full mtop10">
                    {this.state.template.action === 'modify' ? 
                      <h1>Modify template</h1>
                    :
                    <h1>Edit new template</h1>
                    }
                <p>
                   Template:{this.state.template.template} | Component : {this.state.template.component}
                </p>
                {this.state.serverResponse.status === null ?
                 <div>
                    <hr/>
                    <textarea className="template-modifier" value={this.state.html} onChange={this.onChangeFunction.bind(this)} onInput={this.updateTemplatePreviewer.bind(this)}></textarea>
                    <hr/>
                    <button  className="inline-block modify-template-back-btn f-left" onClick={this.goBack.bind(this)} value="TemplateEditor">
                    <i className="fa fa-chevron-left"></i> BACK
                   </button>
                    <button  className="inline-block modify-template-btn f-right" onClick={this.saveChanges.bind(this)}>
                    {this.state.template.action === 'modify' ?
                    <span>SAVE MODIFICATIONS</span>
                    :
                    <span>SAVE NEW TEMPLATE</span>
                    }
                    </button>
                 </div>
                 :
                 <div>
                  <hr/>
                   <p>{this.state.serverResponse.message}</p>
                  <hr/> 
                   {this.state.serverResponse.status === '400' ?
                   <button  className="inline-block modify-template-back-btn" onClick={this.resetServerResponse.bind(this)}>
                    <i className="fa fa-chevron-left"></i> BACK
                   </button>
                   :
                   <div>

                    <button  className="inline-block modify-template-back-btn f-left" onClick={this.goBack.bind(this)} value="TextEditor">
                       PREPARE EMAIL MESSAGE
                    </button>

                    <button  className="inline-block modify-template-btn f-right" onClick={this.goBack.bind(this)} value="TemplateEditor">
                        {this.state.template.action === 'modify' ? 
                         <span>Modify new template</span>
                        :
                        <span>Create new template</span>
                        }
                    </button>
                   </div>
                   }
                 </div>
                 }
                </div>
               </div>
            </div>
         
            <Preloader showPreloader={this.state.showPreloader} />
         </div>
        );
      }


}