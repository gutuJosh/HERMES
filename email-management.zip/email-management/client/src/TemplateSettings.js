import React from 'react';
import InputBox from './components/InputBox';
import Preloader from './components/Preloader';
import SelectBox from './components/SelectBox';
import Label from './components/Label';
import AppStore from './stores/AppStore.js';
import { setHT, setWidget, setSignature, setPreloaderStatus } from './actions/AppActions.js';
import axios from 'axios';

export default class EmailRecipients extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           textBlocks:'',
           highlightedTexts:[],
           widgets:[],
           firma:'',
           bcc:[],
           cc:[],
           fromName:'',
           fromEmail:'',
           subject:'',
           name:'',
           updatedValue: null,
           formSuccess: false,
           formError: false,
           serverResponse: ''
        }

        this._onPreload = this._onPreload.bind(this);
        this.handleInputValue = this.handleInputValue.bind(this);
    }

    componentWillMount(){
        AppStore.addChangeListener(this._onPreload);
        this.setState({'showPreloader':AppStore.getPreloaderStatus(), language:this.props.returnComponentState('language')});
        
    }

    componentWillUnmount() {
        AppStore.removeChangeListener(this._onPreload);
    }

    componentDidMount(){
        setTimeout(
            function(){
                setPreloaderStatus('hidden');
            }, 500);
    }

    _onPreload(status){
        this.setState({'showPreloader':AppStore.getPreloaderStatus()});
    }


    getComponentInfo(value){

        if(value === ''){
            let obj = {name:'', textBlocks:'', highlightedTexts:[], widgets:[], fromEmail:'',fromName:'',firma:'', bcc: [], cc: [], subject:'', updatedComponent:null};
            for(let key in obj){
                this.setState({[key]: obj[key]});
            }
            let updateTemplatePreviewer = {'templateBody': '', body: null, textBlocks:{content:'', name:''}, ht:[], widgets:[], fromName: null, fromEmail: null, bcc:[], cc: [], subject:null}
            this.props.handleState(updateTemplatePreviewer, false);
            setHT([]);
            setWidget([]);
            setSignature('');
        }
        else{
            setPreloaderStatus('show');
            let componentInfo = JSON.parse(value);
            let self = this;
            //display template in template previewer
            axios.post('/templatemanager',
            {
             templateName: encodeURIComponent(componentInfo.name),
             language: this.state.language
            }
            ).then(function (response) {
                self.props.handleState(response.data[0].info, false);
                self.props.handleState('templateBody',response.data[0].info.body);
                setPreloaderStatus('hidden');
            }).catch(function (error) {
                console.log(error);
            });
            for(let key in componentInfo){
                this.setState({[key]: componentInfo[key]});
            }
        }
        
    }

    handleInputValue(fieldName, inputValue){
        if(fieldName === 'highlightedTexts' || fieldName === 'widgets' || fieldName === 'bcc' || fieldName === 'cc'){
            inputValue = inputValue.replace(/ /g, '');
            inputValue = inputValue !== '' ? inputValue.split(',') : [];
            let items = []
            for(let i = 0; i < inputValue.length; i++){
                  if(inputValue[i] !== ''){
                    items.push(inputValue[i]);
                  }
            }

            inputValue = items;
        }
        this.setState({[fieldName]:inputValue});
    }

   saveSettings(event){
     //event.preventDefault();
   if(event.target.value !== ''){
        let self = this;
        let templateName = event.target.value;
        setPreloaderStatus('show');
        axios.post('/settings',
         {
            templateName: encodeURIComponent(templateName),
            language: encodeURIComponent(this.state.language),
            textBlocks: encodeURIComponent(this.state.textBlocks),
            firma: encodeURIComponent(this.state.firma),
            fromEmail: encodeURIComponent(this.state.fromEmail),
            fromName: encodeURIComponent(this.state.fromName),
            bcc: encodeURIComponent(this.state.bcc),
            cc: encodeURIComponent(this.state.cc),
            subject: encodeURIComponent(this.state.subject),
            highlightedTexts: encodeURIComponent(JSON.stringify(this.state.highlightedTexts)),
            widgets: encodeURIComponent(JSON.stringify(this.state.widgets))
         }
        ).then(function(response) {
            
            if(response.data[0].status === 200){
             let obj = {name: templateName, textBlocks:self.state.textBlocks, highlightedTexts: self.state.highlightedTexts, widgets: self.state.widgets, firma: self.state.firma,fromEmail: self.state.fromEmail,fromName: self.state.fromName,bcc: self.state.bcc, cc: self.state.cc, subject: self.state.subject};
              self.setState({updatedValue:obj, formSuccess: true, serverResponse:response.data[0].message});
            }
            else{
                self.setState({formError: true, serverResponse:response.data[0].message});
            }
            setTimeout(function(){
                self.setState({updatedValue:null, formError: false, formSuccess: false, serverResponse:''});   
            },5000);
                
            
            setPreloaderStatus('hidden');
       }).catch(function (error) {
            setPreloaderStatus('hidden');  
      });
     }
   }


   closeLabel(){
     this.setState({updatedValue:null, formSuccess: false, formError: false, serverResponse:''});
   }
    

    render() {
        let labelType = !this.state.formError ? 'label-success' : 'label-error';
        return (
          <div id="draftContentEditor" className="flex-item template-settings">
           <div className="row email-recipients-field-holder">
            <div className="col-full mtop10">
            <h1>Template Settings</h1>
             <p>
                 Select a template from the list bellow
             </p>
             <SelectBox language={this.state.language} handleChange={this.getComponentInfo.bind(this)} value={this.state.updatedValue}/>
             <hr/>
            </div>
            {this.state.serverResponse !== '' &&
             <Label type={labelType} message={this.state.serverResponse} action={this.closeLabel.bind(this)}/>
            }
             <InputBox title="TB" name="textBlocks" placeholder="Text Blocks" defaultValue={this.state.textBlocks} handleInput={this.handleInputValue} />
             <InputBox title="HT" name="highlightedTexts" placeholder="Highligted text" defaultValue={this.state.highlightedTexts.join(',')} handleInput={this.handleInputValue}/>
             <InputBox title="Firma" name="firma" placeholder="Firma" defaultValue={this.state.firma} handleInput={this.handleInputValue}/>
             <InputBox title="Widgets" name="widgets" placeholder="Widgets" defaultValue={this.state.widgets.join(',')} handleInput={this.handleInputValue}/>
             <InputBox title="From name" name="fromName" placeholder="From name" defaultValue={this.state.fromName} handleInput={this.handleInputValue}/>
             <InputBox title="From email" name="fromEmail" placeholder="From email" defaultValue={this.state.fromEmail} handleInput={this.handleInputValue}/>
             <InputBox title="cc" name="cc" placeholder="Insert carbon copy" defaultValue={this.state.cc.toString()} handleInput={this.handleInputValue}/>
             <InputBox title="bcc" name="bcc" placeholder="Insert blind carbon copy" defaultValue={this.state.bcc.toString()} handleInput={this.handleInputValue}/>
             <InputBox title="Subject" name="subject" placeholder="Insert subject" defaultValue={this.state.subject} handleInput={this.handleInputValue}/>
          
            <hr/>
            <div className="row mtop10">
            {this.state.serverResponse !== '' &&
             <Label type={labelType} message={this.state.serverResponse} action={this.closeLabel.bind(this)}/>
            }
            <div className="col-lg-12 col-md-12 col-sm-12 text-center pad5">
             <button onClick={this.saveSettings.bind(this)} value={this.state.name} className="send-email-btn inline-block">Save settings</button>
            </div>
           </div>
            
          </div>
          <Preloader showPreloader={this.state.showPreloader} />
         </div>
        );
      }


}