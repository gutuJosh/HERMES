import React from 'react';
import axios from 'axios';
import SelectTemplates from './components/SelectTemplates';
import SelectEmailBlock from './components/SelectEmailBlock';
import AppStore from './stores/AppStore.js';
import { setHT, setWidget, setSignature, setPreloaderStatus} from './actions/AppActions.js';

export default class TemplateManagerMenu extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            htTemplates: [],
            widgetTemplates: [],
            activeHt: [],
            activeWidgets: [],
            activeSignature: '',
            componentIndex: null
          }
        this.handleEmailComponents = this.handleEmailComponents.bind(this);
        this.loadNewTemplate = this.loadNewTemplate.bind(this);
        this.loadEmailComponent = this.loadEmailComponent.bind(this);
        this.loadFirma = this.loadFirma.bind(this);
        this.deleteEmailComponent = this.deleteEmailComponent.bind(this);
        this._onHt = this._onHt.bind(this);
        this._onSignature = this._onSignature.bind(this);
        this._onWidget = this._onWidget.bind(this);
    }

     componentWillMount(){
         /*get all available file */
        var self = this;
        fetch('/templatemanager/readdir/ht/?language='+encodeURIComponent(this.props.returnComponentState('language')))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.setState({htTemplates:data[0].items});
              }
              else{
                  console.log(data[0].status);
              }
           });
        });
        fetch('/templatemanager/readdir/widgets/?language='+encodeURIComponent(this.props.returnComponentState('language')))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.setState({widgetTemplates:data[0].items});
              }
              else{
                  console.log(data[0].status);
              }
           });
        });
     }

      componentDidMount(){
        AppStore.addChangeListener(this._onHt);
        AppStore.addChangeListener(this._onWidget);
        AppStore.addChangeListener(this._onSignature);
      }
  
      componentWillUnmount() {
        AppStore.removeChangeListener(this._onHt);
        AppStore.removeChangeListener(this._onWidget);
        AppStore.removeChangeListener(this._onSignature);
      }
  
  
      _onHt() {
        this.setState({activeHt:AppStore.getHT()});
      }

      _onWidget() {
        this.setState({activeWidgets:AppStore.getWidgets()});
        
      }

      _onSignature() {
        this.setState({activeSignature:AppStore.getSignature()});
      }


    handleEmailComponents(event){
        //event.preventDefault();
        if(event.target.checked === true){
          this.loadEmailComponent(event.target.getAttribute('data-name'), event.target.value.replace('.html',''));
        }
        else{
          this.deleteEmailComponent(event.target.getAttribute('data-name'), event.target.value.replace('.html',''));
        }
    }

  

    loadNewTemplate(templateName){
        setPreloaderStatus('show');
        var self = this;
        axios.post('/templatemanager',
        {
          templateName: encodeURIComponent(templateName.replace('.html','')),
          language: this.props.returnComponentState('language')
        }
        ).then(function (response) {
            self.props.updateTemplateInfo(response.data[0].info, templateName);
            setSignature(response.data[0].info.nomeFirma);
            if(templateName === '_blank'){
                self.setState({activeWidgets: [], activeHt: [], activeSignature:''});
                setHT([]);
                setWidget([]);
                setSignature('');
            }
            setPreloaderStatus('hidden');
        }).catch(function (error) {
            console.log(error);
        });
    }

    loadEmailComponent(component, componentName){
       setPreloaderStatus('show');
        let self = this;
        fetch('/templatemanager/readfile/'+component+'/'+componentName+'/?language='+encodeURIComponent(this.props.returnComponentState('language')))
         .then(function(response){
            response.json().then(function(data){
              if(data[0].status === 200){
                let items = self.props.returnComponentState(component);
                items.push(data[0].content);
                //update the state of the parent component
                self.props.handleState(component,items);
                if(self.state.componentIndex !== null){
                  self.setOrder(self.state.componentIndex,  componentName, component);
                  self.setState({componentIndex: null});
                }
              }
              else{
                  console.log(data[0].content);
              }
              setPreloaderStatus('hidden');
           });
         });
    }

    loadFirma(componentName){
      let self = this;
      setPreloaderStatus('show');
      if(componentName === '_blank'){
        self.props.handleState('firma','');
        self.props.handleState('nomeFirma','');
        self.setState({activeSignature: ''});
        setSignature('');
        setPreloaderStatus('hidden');
        return;
      }
      fetch('/templatemanager/readfile/firma/'+componentName.replace('.html','')+'/?language='+encodeURIComponent(this.props.returnComponentState('language')))
       .then(function(response){
          response.json().then(function(data) {
            if(data[0].status === 200){
              //update the state of the parent component
              self.props.handleState('firma',data[0].content.content);
              self.props.handleState('nomeFirma',data[0].content.name);
              setSignature(data[0].content.name);
            }
            else{
                console.log(data[0].status);
            }
            setPreloaderStatus('hidden');
         });
       });
    }

    deleteEmailComponent(componentName, blockName){
       let items = this.props.returnComponentState(componentName);
       for(let i=0; i < items.length; i++){
           if(items[i].name === blockName){
              items.splice(i,1);
              break;
           }
       }
       //update the state of the parent component
       this.props.handleState(componentName,items);
    }

    handleComponentOrder(event){
       event.preventDefault();
       let getvalue = event.target.value;
       let componentName = event.target.name;
       let itemName = event.target.getAttribute('data-id');
       let checkBox = event.target.parentNode.firstChild;
      
       if(getvalue !== '' && getvalue.length === 1){
          if(isNaN(getvalue)){
            event.target.value = '';
            return;
          }

          if(checkBox.checked === false){
              checkBox.checked = true;
              this.setState({componentIndex: getvalue});
              this.loadEmailComponent(checkBox.getAttribute('data-name'), checkBox.value.replace('.html',''));
              return;
          }
          else{
            this.setOrder(getvalue, itemName, componentName);
          }

          
      }
    }


    setOrder(orderIndex, itemName, componentName){

      if(orderIndex === '' || orderIndex === undefined || componentName === '' || componentName === undefined || itemName === '' || itemName === undefined){
        return false;
      }

      let swapIndex = null;
      let getvalue = orderIndex;
      let items = this.props.returnComponentState(componentName);

      for(let i = 0; i < items.length; i++){
        if(items[i].name === itemName){
          swapIndex = i;
        }
      }

      if(getvalue > items.length){
            getvalue = items.length;
      }

      if(getvalue < 1){
        getvalue = 1;
      }

      getvalue = (getvalue <= items.length) ? (getvalue-1) : getvalue;

      if(items[getvalue] !== undefined){
          let itemToSwap = items[swapIndex];
          let oldItem = items[getvalue];
          items.splice(getvalue, 1, itemToSwap);
          items.splice(swapIndex, 1, oldItem);
          this.props.handleState(componentName,items);
      } 

    }


    render() {
     
        return (
           <div className="templateManagerMenu row">
            <div className="col-md-4 col-sm-4 col-xs-4">
             <SelectTemplates loadTemplate={this.loadNewTemplate} returnComponentState={this.props.returnComponentState} componentName="body" title="Select a template" />
            </div>
            <div className="col-md-4 col-sm-4 col-xs-4">
             <SelectTemplates loadTemplate={this.loadFirma} setComponentState={this.props.handleState} returnComponentState={this.props.returnComponentState} componentName="firma" title="Select signature" defaultValue={this.state.activeSignature}/>
             </div>
            <div className="col-md-4 col-sm-4 col-xs-4">
             <SelectEmailBlock handleChange={this.handleEmailComponents} handleComponentOrder={this.handleComponentOrder.bind(this)} componentName="ht" activeItems={this.state.activeHt} templates={this.state.htTemplates}/>
             </div>
            <div className="col-md-4 col-sm-4 col-xs-4"> 
             <SelectEmailBlock handleChange={this.handleEmailComponents} handleComponentOrder={this.handleComponentOrder.bind(this)} componentName="widgets" activeItems={this.state.activeWidgets} templates={this.state.widgetTemplates}/>
            </div>
           </div> 
        );

    };
}