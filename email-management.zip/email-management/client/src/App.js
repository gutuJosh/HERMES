import React from 'react';
import Header from './Header';
import Footer from './Footer';
import TextEditor from './TextEditor';
import TemplatePreviewer from './TemplatePreviewer';
import EmailRecipients from './EmailRecipients';
import SendNewEmail from './SendNewEmail';
import TemplateSettings from './TemplateSettings';
import TemplateEditor from './TemplateEditor';
import EditTemplate from './EditTemplate';
import axios from 'axios';
import { setHT, setWidget, setSignature, setPreloaderStatus } from './actions/AppActions.js';
import { replaceHtmlTags} from './helpers/Helpers.js';


export default class App extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
          login: '',
          activeComponent: 'TextEditor',
          language: 'en',
          query:null,
          templateBody:'',
          body:null,
          ht:[],
          widgets:[],
          textBlocks: {content:'', name:''},
          firma: '',
          nomeFirma:null,
          firmaPosition: 'end',
          to: null,
          fromName:null,
          fromEmail:null,
          bcc:[],
          cc:[],
          subject:null,
          attachments:null,
          wasEmailSend: null,
          previewContent:''
      }
      this.handleComponentState = this.handleComponentState.bind(this);
      this.returnComponentState = this.returnComponentState.bind(this);
      this.replaceTags = this.replaceTags.bind(this);
    }



    async componentWillMount(){
       if(window.location.search.length > 0){ 
        const query = window.location.search.substring(1); 
        let items = query.split('&');
        let obj ={};
        for(let i = 0; i < items.length; i++){
            let vars = items[i].split('='); 
            obj[vars[0]] = decodeURIComponent(vars[1]);  
            
        }
        if(Object.keys(obj).length > 0){
          this.setState({query: obj});
          if(obj['lang'] !== undefined && obj['lang'] !== ''){
             this.setState({language: obj['lang'].substring(0,2)});

          }
          if(obj['to'] !== undefined && obj['to'] !== ''){
            this.setState({to: obj['to']});
          }
          if(obj['cc'] !== undefined && obj['cc'] !== ''){
             this.setState({cc: obj['cc'].split(',')});
          }
          if(obj['sign'] !== undefined && obj['sign'] !== ''){
             this.setState({nomeFirma: obj['sign']});
             setSignature(obj['sign']);
          }
          if(obj['ht'] !== undefined && obj['ht'] !== ''){
            let ht = decodeURIComponent(obj['ht']);
            let tags = obj['ht-tags'] !== undefined ? JSON.parse(decodeURIComponent(obj['ht-tags'])) : null;
            let _getHt = this.state.ht;
            let lang = (obj['lang'] !== undefined && obj['lang'] !== '') ? obj['lang'].substring(0,2) : this.state.language;
            let loadHt =  await fetch(`/templatemanager/readfile/ht/${encodeURIComponent(ht)}/?language=${lang}`);
            let htTemplate = await loadHt.json();
            if(htTemplate[0].status === 200){
                let ht_Template = htTemplate[0].content;
                let htTags = (tags !== null) ? tags : [];
                
                ht_Template.content = replaceHtmlTags(ht_Template.content,htTags);
                
                _getHt.push(ht_Template);
                this.setState({'ht':_getHt,'htDynamicComponent':{'type':'ht', 'name':ht, 'values':JSON.stringify(tags)}});
            }
            
          }
        }
        if(obj['widgets'] !== undefined && obj['widgets'] !== ''){
            let wig = decodeURIComponent(obj['widgets']);
            let tags = obj['widgets-tags'] !== undefined ? JSON.parse(decodeURIComponent(obj['widgets-tags'])) : null;
            let _getWidgets = this.state.widgets;
            let lang = (obj['lang'] !== undefined && obj['lang'] !== '') ? obj['lang'].substring(0,2) : this.state.language;
            let loadWidget =  await fetch(`/templatemanager/readfile/widgets/${wig}/?language=${lang}`);
            let widgetTemplate = await loadWidget.json();
            if(widgetTemplate[0].status === 200){
                let widget_Template = widgetTemplate[0].content;
                let widgetTags = (tags !== null) ? tags : [];

                 widget_Template.content = replaceHtmlTags(widget_Template.content,widgetTags);

                _getWidgets.push(widget_Template);
                this.setState({'widgets': _getWidgets,'widgetDynamicComponent':{'type':'widget', 'name':wig, 'values':JSON.stringify(tags)}});
            } 
        }
       }
       else{
        this.getCurrentLanguage.bind(this);
       }
    }

    async componentDidMount(){
       //Load a template and replace [tags] with url given values
       if(this.state.query!=null && this.state.query['type'] !== undefined){

            var getTemplate = () => { 
                return new Promise((resolve, reject) => {
                        axios.post('/templatemanager',
                        {
                        templateName: encodeURIComponent(this.state.query['type']),
                        language: this.state.language,
                        nomeFirma: this.state.nomeFirma
                        }
                        ).then(function (response) {
                            resolve(response);
                        }).catch(function (error) {
                            reject(error);
                        }); 
                    });
            }
            var tmp = await getTemplate();
            for (var key in tmp.data[0].info) {
                //particular case of 'cc' field
                //the value of this field must be concatenated to the value pased in get
                if(key === 'cc'){
                    let default_cc = (this.state.cc.length > 0 && tmp.data[0].info[key] !== '') ? ','+tmp.data[0].info[key] : tmp.data[0].info[key];
                    let get_cc = this.state.cc.length > 0 ? this.state.cc.join() + default_cc : default_cc;
                    if(!Array.isArray(get_cc)){
                    this.setState({[key] : get_cc.split()});
                    }
                } 
                else if(key === 'nomeFirma'){
                    if(this.state.nomeFirma === null || this.state.nomeFirma === ''){
                    this.setState({nomeFirma : tmp.data[0].info[key]});
                    }
                }
            
                else{
                    if(key === 'ht' && this.state.query['ht'] !== undefined){
                        let currentHt = this.state.ht;
                        let ht = tmp.data[0].info[key];
                        for(let i = 0; i < ht.length; i++){
                            currentHt.push(ht[i]);
                        }
                        this.setState({'ht' : currentHt}); 
                   }
                   else if(key === 'widgets' && this.state.query['widgets'] !== undefined){
                        let currentWidgets = this.state.widgets;
                        let wg = tmp.data[0].info[key];
                        for(let i = 0; i < wg.length; i++){
                            currentWidgets.push(wg[i]);
                        }
                        this.setState({'widgets' : currentWidgets});
                   }
                   else{
                       this.setState({[key] : tmp.data[0].info[key]});
                   }
                    
                }
            }
            this.replaceTags(this.state.query, this.state.body);
       }
    }

    replaceTags(query, template){
        let _self = this;
        let keys = Object.keys(query).toString().replace(/,/g, '_-_|__');
        let templateBody = template.replace(/\[/g,'__').replace(/\]/g,'_-_');
        let pattern = new RegExp('__'+keys+'_-_', "g");
        
        let replaceTemplate = templateBody.replace(pattern, function myFunction(key){
            
            let item = key.replace(/__/g,'').replace(/_-_/g,'');
            return _self.state.query[item];
        });
        
        replaceTemplate = replaceTemplate.replace(/__/gm, '[').replace(/_-_/g,']');

        this.setState({templateBody: replaceTemplate, body:replaceTemplate});
        //replace tags in email subject
        if(this.state.subject !== null){
            let subject = this.state.subject.replace(/\[/g,'__').replace(/\]/g,'_-_');
                subject = subject.replace(pattern, function myFunction(key){
                let item = key.replace(/__/g,'').replace(/_-_/g,'');
                return _self.state.query[item];
            });
            for (let key in query) {
              let item = key.replace(/__/g,'').replace(/_-_/g,'');
              subject = subject.replace('['+query[item]+']', query[item]);
            }
            if(this.state.subject !== subject){
                this.setState({subject: subject});
            }
        } 
    }


    handleComponentState(componentName, stateValue){
        if(typeof(componentName) === 'object'){
            for (var key in componentName) {
                this.setState({[key]:componentName[key]}); 
            }
        }
        else{
         this.setState({[componentName]: stateValue});
        }
    }

    returnComponentState(componentName) {
       
        return this.state[componentName];
    }


    splitComponent(component, action){
        let ht = component;
        let _ht = [];
        let _htNames = [];
        for(let i=0; i < ht.length; i++){
           _ht.push(ht[i].content);
           _htNames.push(ht[i].name);
        }
        return action === 'name' ? _htNames : _ht;
    }


    getCurrentLanguage(){
        let self = this;
        fetch('/language')
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.setState({language:data[0].language});
              }
              else{
                  console.log('Error while get current language!');
                  self.setState({language:'it'});
              }
           });
         });   
    }


    previewEmail(_ht, _widget){
        let content = '';
        if(this.state.firmaPosition === 'before'){
           content = this.state.templateBody+this.state.textBlocks.content+this.state.firma+_ht.join('')+_widget.join('');
        }
        else{
            content = this.state.templateBody+this.state.textBlocks.content+_ht.join('')+_widget.join('')+this.state.firma;
        }
        return content;
    }



    sendEmail(){
        //make shure we somme content to send
        if(this.state.templateBody === ''){
             return false;
        }
        let self = this;
        setPreloaderStatus('show');
        axios.post('/sendmail',
              {
                message: encodeURIComponent(this.state.templateBody),
                attachments: this.state.attachments,
                language: encodeURIComponent(this.state.language),
                emailInfo: {
                    to: encodeURIComponent(this.state.to),
                    fromEmail: encodeURIComponent(this.state.fromEmail),
                    fromName: encodeURIComponent(this.state.fromName),
                    bcc: encodeURIComponent(JSON.stringify(this.state.bcc)),
                    cc: encodeURIComponent(JSON.stringify(this.state.cc)),
                    subject: encodeURIComponent(this.state.subject),
                    ht: encodeURIComponent(JSON.stringify(this.splitComponent(this.state.ht, 'name'))),
                    widgets: encodeURIComponent(JSON.stringify(this.splitComponent(this.state.widgets, 'name'))),
                    textBlocks: encodeURIComponent(this.state.textBlocks.name),
                    firma: encodeURIComponent(this.state.nomeFirma),
                    firmaPosition: this.state.firmaPosition
                },
                htDynamicComponent : this.state.htDynamicComponent !== undefined ? encodeURIComponent(JSON.stringify(this.state.htDynamicComponent)) : '',
                widgetDynamicComponent: this.state.widgetDynamicComponent !== undefined ? encodeURIComponent(JSON.stringify(this.state.widgetDynamicComponent)) : ''
              }
        ).then(function (response) {
            setPreloaderStatus('hidden');
            self.handleComponentState('attachments', null);
            self.setState({wasEmailSend: {status: response.data.status, message: response.data.message}, activeComponent: 'SendNewEmail'}); 

       }).catch(function (error) {
            setPreloaderStatus('hidden');
            self.setState({wasEmailSend: {status: 400, message: error}, activeComponent: 'SendNewEmail'}); 
            
      });
    }

    render() {

       let _widget = this.splitComponent(this.state.widgets, 'component')
       setWidget(this.splitComponent(this.state.widgets, 'name'));

       let _ht = this.splitComponent(this.state.ht, 'component');
       setHT(this.splitComponent(this.state.ht, 'name'));

       let content = this.previewEmail(_ht, _widget);
        
       const TagName = {'TextEditor' : TextEditor, 'EmailRecipients' : EmailRecipients, 'SendNewEmail' : SendNewEmail, 'TemplateSettings' : TemplateSettings, 'TemplateEditor' : TemplateEditor, 'EditTemplate' : EditTemplate};
       let tagNameProps = [];
       tagNameProps['handleState'] = this.handleComponentState;
       tagNameProps['returnComponentState'] = this.returnComponentState;
       if(this.state.activeComponent === 'TextEditor'){
        tagNameProps['template'] = this.state.body;
        tagNameProps['query'] = this.state.query;
       }
       if(this.state.activeComponent === 'EmailRecipients'){
        tagNameProps['sendAction'] = this.sendEmail.bind(this);
       }
       var ActiveComponent = TagName[this.state.activeComponent];
       
       return (
        <div className="app-body">
          <Header returnComponentState={this.returnComponentState} handleComponentState={this.handleComponentState}/>
           <main className="flex flex-row">
            <TemplatePreviewer templateBody={content} language={this.state.language}/>
            <ActiveComponent {...tagNameProps}/>
           </main>
          <Footer handleComponentState={this.handleComponentState} returnComponentState={this.returnComponentState}/>
        </div>
        );
      }



    
}