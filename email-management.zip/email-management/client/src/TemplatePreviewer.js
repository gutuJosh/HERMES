import React from 'react';

export default class TemplatePreviewer extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            templateHeader:'',
            templateFooter:''
        }
    }

    componentDidMount(){
        let self = this;
        fetch('/templatemanager/layout/?language='+encodeURIComponent(this.props.language))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.setState({templateHeader:data[0].header, templateFooter:data[0].footer});
              }
              else{
                  console.log(data[0].status);
              }
           });
         });
    }

    render() {
        let content = this.state.templateHeader+this.props.templateBody+this.state.templateFooter;
        content = content.replace(/<a/g, '<a target="_blank"');
        return (
            <iframe srcDoc={content} title="coolEditor" className="flex-item"></iframe>
        );

    };
}