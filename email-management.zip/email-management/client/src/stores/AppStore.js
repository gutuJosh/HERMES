// App store
// Requiring the Dispatcher, ActionTypes, and
// event emitter dependencies
import AppDispatcher from '../dispatcher/AppDispatcher.js';
import { ActionTypes } from '../actions/ActionTypes.js';
import { EventEmitter } from 'events';

const CHANGE_EVENT = 'change';

// Define the stores as an empty arrays
let _body = '';
let _ht = [];
let _widgets = [];
let _signature = '';
let _preloaderStatus = 'hidden';
let _templateEditor = {};

// Define the public event listeners and getters that
// the views will use to listen for changes and retrieve
// the store
class AppStoreClass extends EventEmitter {

  addChangeListener(cb) {
    this.on(CHANGE_EVENT, cb);
  }

  removeChangeListener(cb) {
    this.removeListener(CHANGE_EVENT, cb);
  }


  getHT() {
    return _ht;
  }

  getWidgets() {
    return _widgets;
  }

  getSignature() {
    return _signature;
  }

  getBody() {
    return _body;
  }

  getPreloaderStatus() {
    return _preloaderStatus;
  }

  getTemplateEditor() {
    return _templateEditor;
  }

}

// Initialize the singleton to register with the
// dispatcher and export for React components
const AppStore = new AppStoreClass();

// Register each of the actions with the dispatcher
// by changing the store's data and emitting a
// change
AppDispatcher.register((payload) => {
  const action = payload.action;

  switch (action.actionType) {
  // change current language
  // Add the data defined in the AppActions
   case ActionTypes.SET_WIDGET:
    _widgets = action.object;
   AppStore.emit(CHANGE_EVENT);
   break;

   case ActionTypes.SET_HT:
     _ht = action.object;
    AppStore.emit(CHANGE_EVENT);
    break;

    case ActionTypes.SET_SIGNATURE:
     _signature = action.text;
    AppStore.emit(CHANGE_EVENT);
    break;

    case ActionTypes.SET_BODY:
     _body = action.text;
    AppStore.emit(CHANGE_EVENT);
    break;

    case ActionTypes.SHOW_PRELOADER:
     _preloaderStatus = action.text;
    AppStore.emit(CHANGE_EVENT);
    break;

    case ActionTypes.SET_TEMPLATE_EDITOR:
     _templateEditor = action.object;
    AppStore.emit(CHANGE_EVENT);
    break;

    default:
       break;
  }
});

export default AppStore;