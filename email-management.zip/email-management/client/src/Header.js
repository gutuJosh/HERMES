import React from 'react';
//import SelectLanguage from './components/SelectLanguage';
import SelectComponent from './components/SelectComponent';
import { setHT, setWidget, setSignature, setPreloaderStatus } from './actions/AppActions.js';

export default class Header extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        
      }
    }


    handleComponents(event){
      //event.preventDeafult();
      if(this.props.returnComponentState('activeComponent') !== event.target.value){
        setPreloaderStatus('show');
        this.props.handleComponentState('activeComponent', event.target.value);
      }
      document.querySelector('.main-components-selector').checked = false;
      //update template previewer
      let updateTemplatePreviewer = {'templateBody': '', body: null, ht:[], widgets:[], textBlocks: {content:'', name:''}, fromName: null, fromEmail: null, bcc:[], cc: [], subject:null}
      this.props.handleComponentState(updateTemplatePreviewer, false);
      setHT([]);
      setWidget([]);
      setSignature('');
    }



    render() {
        return (
          <header className="app-header">
           <SelectComponent componentName={this.props.returnComponentState('activeComponent')} handleComponents={this.handleComponents.bind(this)}/>
           <p className="text-sky-blue">
             <img src="/images/logo.png"  alt="logo" className="logo inline-block"  title="Email generator"/>
           </p>
          </header>
        );
      }


}