//actions
import AppDispatcher from '../dispatcher/AppDispatcher.js';
import { ActionTypes } from './ActionTypes.js';

export function setBody(text) {
  AppDispatcher.handleViewAction({
    actionType: ActionTypes.SET_BODY,
    text: text,
  });
}

export function setHT(object) {
    AppDispatcher.handleViewAction({
      actionType: ActionTypes.SET_HT,
      object: object,
    });
  }

  export function setWidget(object) {
    AppDispatcher.handleViewAction({
      actionType: ActionTypes.SET_WIDGET,
      object: object,
    });
  }

  export function setSignature(text) {
    AppDispatcher.handleViewAction({
      actionType: ActionTypes.SET_SIGNATURE,
      text: text,
    });
  }

  export function setPreloaderStatus(text) {
    AppDispatcher.handleViewAction({
      actionType: ActionTypes.SHOW_PRELOADER,
      text: text,
    });
  }

  export function setTemplateEditor(object) {
    AppDispatcher.handleViewAction({
      actionType: ActionTypes.SET_TEMPLATE_EDITOR,
      object: object,
    });
  }