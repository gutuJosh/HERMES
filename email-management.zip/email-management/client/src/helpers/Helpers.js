export function replaceHtmlTags(input, tags) {
    let html = '';
    for(let i = 0; i < tags.length; i++){
        let component_tags = Object.keys(tags[i]);
        for(let z = 0; z < component_tags.length; z++){
            let chunck = input.replace(/\[/g,'__').replace(/\]/g,'__');
            let pattern = new RegExp('__'+component_tags[z]+'__', "g");
            html = chunck.replace(pattern,tags[i][component_tags[z]]);
        }; 
    }

    return html !== '' ?  html : input;
}

