import React from 'react';
import Preloader from './components/Preloader';
import RadioBtn from './components/RadioBtn';
import SimpleInputField from './components/SimpleInputField';
import SimpleSelect from './components/SimpleSelect';
import Label from './components/Label';
import { setPreloaderStatus, setTemplateEditor } from './actions/AppActions.js';
import axios from 'axios';

export default class TemplateEditor extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           action: null,
           template: null,
           disabled: 'disabled',
           body: {status:'disabled', templateName: null, data:[]},
           ht: {status:'disabled', templateName: null, data:[]},
           firma: {status:'disabled', templateName: null, data:[]},
           tb: {status:'disabled', templateName: null, data:[]},
           widgets: {status:'disabled', templateName: null, data:[]},
           showPreloader: 'show',
           serverResponse: {status:null, message:null}
        }
        
   
    }


    componentDidMount(){
        let self = this;
        setTimeout(
            function(){
                self.setState({'showPreloader': 'hidden'});
            }, 500);
    }


    setActiveComponent(actionName){
      this.setState({action: actionName, template: null, disabled:''});
      this.props.handleState({'templateBody':''}, false);
    }

    setTemplateType(templateType){
      let template='';
      let _body = {status: 'disabled', templateName: null, data:this.state.body.data},
          _ht = {status: 'disabled', templateName: null, data:this.state.ht.data},
          _firma = {status: 'disabled', templateName: null, data:this.state.firma.data},
          _tb = {status: 'disabled', templateName: null, data:this.state.tb.data},
          _widgets = {status: 'disabled', templateName: null, data:this.state.widgets.data};
      this.setState({template: null, body: _body, ht: _ht, firma: _firma, tb: _tb, widgets: _widgets});

      if(this.state.action === 'new'){
         template = {status: 'enabled', templateName: null, data: this.state[templateType].data};
         this.setState({[templateType]: template});
      }  
      else{
        if(this.state[templateType].data.length === 0){  
            setPreloaderStatus('show');
            let self = this;
            fetch('/templatemanager/readdir/'+templateType+'/?language='+encodeURIComponent(this.props.returnComponentState('language')))
            .then(function(response){
                response.json().then(function(data) {
                if(data[0].status === 200){
                    let template = {status: 'enabled', templateName: null, data: data[0].items};
                    self.setState({[templateType]:template});
                }
                else{
                    console.log(data[0].status);
                }
                setPreloaderStatus('hidden');
            });
            });
        }
        else{
            template = {status: 'enabled', templateName: null, data: this.state[templateType].data};
            this.setState({[templateType]: template});
        }
     }
    }

    getActiveComponent(){
        let _component = null;
        if(this.state.body.status === 'enabled'){
            _component = 'body';
         }
         else if(this.state.ht.status === 'enabled'){
             _component = 'ht';
         }
         else if(this.state.tb.status === 'enabled'){
             _component = 'tb';
         }
         else if(this.state.firma.status === 'enabled'){
             _component = 'firma';
         }
         else if(this.state.widgets.status === 'enabled'){
             _component = 'widgets';
         }
         return _component;
    }


    selectTemplate(_template){
      let tmp = _template !== '' ?  _template.replace(/ /g,'-') : null;
      this.setState({template: tmp});
      var component = this.getActiveComponent();
      if(tmp !== null && component !== null && this.state.action === 'modify'){//preview template
        var self = this;
        fetch('/templatemanager/readfile/'+component+'/'+tmp.replace('.html','')+'/?language='+encodeURIComponent(this.props.returnComponentState('language')))
        .then(function(response){
                response.json().then(function(data) {
                if(data[0].status === 200){
                    self.setState({showPreloader:'hidden','html':data[0].content.content});
                    let obj = {'templateBody': data[0].content.content};
                    self.props.handleState(obj, false);
                }
                else{
                    console.log(data[0].content);
                }
            });
        });
     }
    }



    modifyTemplate(event){
        event.preventDefault();
        
        if(event.target.disabled === false || typeof(event.target.disabled) === 'undefined'){
            this.setState({'showPreloader': 'show'});
            let self = this;
            setTemplateEditor({action:this.state.action, component:this.getActiveComponent(), template:this.state.template});
            setTimeout(
                function(){
                    setPreloaderStatus('hidden');
                    self.props.handleState('activeComponent','EditTemplate');
                }, 500);
        }
    }

    deleteTemplate(event){
        event.preventDefault();
        if(!window.confirm('Are you sure you want to delete '+this.state.template+'?')){
            return false;
        }
        let self = this;
        setPreloaderStatus('show');
        let _component = this.getActiveComponent();  
        if(_component === null){
            return false;
        }
        axios.post('/templatemanager/edit/delete/'+encodeURIComponent(_component)+'/'+encodeURIComponent(this.state.template),
        {
          language: encodeURIComponent(this.props.returnComponentState('language'))
        }
        ).then(function (response) {
            setPreloaderStatus('hidden');
            self.setState({serverResponse: {status:response.data[0].status, message:response.data[0].message}});
         
            if(response.data[0].status === 200){
               let getTmp = self.state[_component].data;
               let i = getTmp.indexOf(self.state.template);
               if(i !== -1) {
                  getTmp.splice(i, 1);
                  self.setState({[_component]: {status: self.state[_component].status, templateName: self.state[_component].templateName, data:getTmp}}); 
               }
               self.props.handleState({'templateBody':''}, false);
            }
            setTimeout(function(){
                self.setState({ serverResponse: {status:null, message:null}});   
            },5000);

        }).catch(function (error) {
            setPreloaderStatus('hidden');
            alert(error);
            
        });
    }

    closeLabel(){
        this.setState({serverResponse: {status:null, message:null}});
    }

    render() {

        let labelType = this.state.serverResponse.status === 200 ? 'label-success' : 'label-error';

        return (
          <div id="draftContentEditor" className="flex-item template-settings">
           <div className="email-recipients-field-holder">
            <div className="row">
                <div className="col-full mtop10">
                <h1>Template Editor</h1>
                <p>
                    What do you want to do?
                </p>
                <hr/>
                </div>
                </div>
                <div className="row mtop10">
                <div className="col-one-half">
                <RadioBtn text="Modify an existing template" value="modify" name="setActiveComponent" disabled="" handleChange={this.setActiveComponent.bind(this)}/>
                </div>
                <div className="col-one-half">
                <RadioBtn text="Create new template" value="new" name="setActiveComponent" disabled="" handleChange={this.setActiveComponent.bind(this)}/>
                </div>
             </div>
             {this.state.serverResponse.message !== null &&
              <Label type={labelType} message={this.state.serverResponse.message} action={this.closeLabel.bind(this)}/>
             }
             <div className="row select-template-type">
              <div className="col-full">
               <hr/>
               <RadioBtn text="Body template" value="body" name="section" disabled={this.state.disabled} handleChange={this.setTemplateType.bind(this)}/>
               {this.state.body.status === 'enabled' && this.state.action === 'new' &&
                 <SimpleInputField name="body" placeholder="Insert new template name" handleChange={this.selectTemplate.bind(this)} onBlur={this.selectTemplate.bind(this)}/>
               }
               {this.state.body.status === 'enabled' && this.state.action === 'modify' &&
                 <SimpleSelect name="selectBodyTemplate" templates={this.state.body.data} handleChange={this.selectTemplate.bind(this)} />
               }
              </div>
              <div className="col-full mtop10">
               <RadioBtn text="Highlighted text" value="ht" name="section" disabled={this.state.disabled} handleChange={this.setTemplateType.bind(this)}/>          
                {this.state.ht.status === 'enabled' && this.state.action === 'new' &&
                 <SimpleInputField name="ht" placeholder="Insert ht template name" handleChange={this.selectTemplate.bind(this)} onBlur={this.selectTemplate.bind(this)}/>
                }
                {this.state.ht.status === 'enabled' && this.state.action === 'modify' &&
                 <SimpleSelect name="selectHtTemplate" templates={this.state.ht.data} handleChange={this.selectTemplate.bind(this)}/>
               }
                </div>
              <div className="col-full mtop10">
               <RadioBtn text="Signature" value="firma" name="section" disabled={this.state.disabled} handleChange={this.setTemplateType.bind(this)}/>
                {this.state.firma.status === 'enabled' && this.state.action === 'new' &&
                 <SimpleInputField name="firma" placeholder="Insert signature name" handleChange={this.selectTemplate.bind(this)} onBlur={this.selectTemplate.bind(this)}/>
                }
                {this.state.firma.status === 'enabled' && this.state.action === 'modify' &&
                 <SimpleSelect name="selectFirmaTemplate" templates={this.state.firma.data} handleChange={this.selectTemplate.bind(this)}/>
                }
               </div>
              <div className="col-full mtop10">
               <RadioBtn text="Table" value="tb" name="section" disabled={this.state.disabled} handleChange={this.setTemplateType.bind(this)}/>
               {this.state.tb.status === 'enabled' && this.state.action === 'new' &&
                 <SimpleInputField name="tb" placeholder="Insert table name" handleChange={this.selectTemplate.bind(this)} onBlur={this.selectTemplate.bind(this)}/>
                }
                {this.state.tb.status === 'enabled' && this.state.action === 'modify' &&
                 <SimpleSelect name="selectTbTemplate" templates={this.state.tb.data} handleChange={this.selectTemplate.bind(this)}/>
               }
              </div>
              <div className="col-full mtop10">
               <RadioBtn text="widgets" value="widgets" name="section" disabled={this.state.disabled} handleChange={this.setTemplateType.bind(this)}/>
               {this.state.widgets.status === 'enabled' && this.state.action === 'new' &&
                 <SimpleInputField name="widgets" placeholder="Insert widgets name" handleChange={this.selectTemplate.bind(this)} onBlur={this.selectTemplate.bind(this)}/>
                }
                {this.state.widgets.status === 'enabled' && this.state.action === 'modify' &&
                 <SimpleSelect name="selectwidgetsTemplate" templates={this.state.widgets.data} handleChange={this.selectTemplate.bind(this)}/>
               }
               <hr/>
               </div>
               
                 <div className="row mtop10">
                  <div className="col-lg-12 col-md-12 col-sm-12 text-center pad5">
                  {this.state.action === 'new' ?
                   <button onClick={this.modifyTemplate.bind(this)} className="inline-block new-template-btn col-full" disabled={this.state.template === null}>
                    <span>Proceed <i className="fa fa-chevron-right"></i></span>
                   </button>
                  :
                  <div>
                   <button onClick={this.deleteTemplate.bind(this)} className="inline-block delte-template-btn f-left" disabled={this.state.template === null}>
                    <span><i className="fa fa-trash"></i> Delete</span>
                   </button>
                   <button onClick={this.modifyTemplate.bind(this)} className="inline-block new-template-btn f-right" disabled={this.state.template === null}>
                    <span>Modify<i className="fa fa-pencil-square-o"></i></span>
                   </button>
                  </div>
                  }
                 </div>
                </div>
                {this.state.serverResponse.message !== null &&
                 <Label type={labelType} message={this.state.serverResponse.message} action={this.closeLabel.bind(this)}/>
                }
             </div>
            </div>
            <Preloader showPreloader={this.state.showPreloader} />
         </div>
        );
      }


}