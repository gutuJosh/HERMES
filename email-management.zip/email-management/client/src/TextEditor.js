import React from 'react';
import ReactDOM from 'react-dom';
import InsertTable from './components/InsertTable';
import TemplateManagerMenu from './TemplateManagerMenu';
import Preloader from './components/Preloader';
import AppStore from './stores/AppStore.js';
import {setPreloaderStatus} from './actions/AppActions.js';

class Editor extends React.Component {
 
  render() {
    return (
      <div id="textEditor" className="textEditor" contentEditable onPaste={this.props.onPaste} onInput={this.props.onChange} onSelect={this.props.onSelect} onBlur={this.props.onBlur} autoFocus>
      </div>
    );
  }
};


export default class TextEditor extends React.Component {

  
  constructor(props) {
    super(props);
    this.state = {
         html:'',
         currentSelection:'',
         editorValue:'',
         htmlTags: false,
         showPreloader: 'hidden'
    };
    this.insertHtml = this.insertHtml.bind(this);
    this.deleteHtml = this.deleteHtml.bind(this);
    this._onPreload = this._onPreload.bind(this);
   
  }

  componentDidMount(){
     AppStore.addChangeListener(this._onPreload);
     let componentBody = this.props.returnComponentState('templateBody');
     if(componentBody !== ''){
       this.deleteHtml();
       this.insertHtml(componentBody);
     }
     if(AppStore.getPreloaderStatus() === 'show'){
      setTimeout(
        function(){
            setPreloaderStatus('hidden');
        }, 500);
      }
  }

  componentWillUnmount() {
        AppStore.removeChangeListener(this._onPreload);
  }


  _onPreload(status){
    this.setState({'showPreloader':AppStore.getPreloaderStatus()});
  }




componentDidUpdate(prevProps, prevState){
   if(prevProps.template !== this.props.template && this.props.template !== null){
     this.deleteHtml();
     this.insertHtml(this.props.template);
   }
   
}




insertHtml(html) {
  try{
    document.execCommand('insertHTML', false, html);
  }
  catch(err){
    console.log(err);
  }
  
}

deleteHtml(){
  try{
    ReactDOM.findDOMNode(this.refs.txteditor).focus();
    document.execCommand('selectAll');
    document.execCommand('delete');
  }
  catch(err){
    console.log(err);
  }
}

createHtml(){
  let html = prompt('Insert html code:','');
  if(html !== null){
    this.insertHtml(html);
  }
}


setSize(){
  let size = prompt('Insert font size (1-7)');
  if(size!=null && this.state.currentSelection.length > 0){
   //var element = '<span style="font-size:'+size.replace('px','')+'px">'+this.state.currentSelection+'</span>';
  // this.insertHtml(element);
  try{
    document.execCommand('fontSize', false, size.replace('px',''));
  }
  catch(err){
    console.log(err);
  }
 }
}



selectTxt(event){
  let text = "";
  if (window.getSelection) {
      text = window.getSelection().toString();
  } else if (document.selection && document.selection.type !== "Control") {
      text = document.selection.createRange().text;
  }
  if(text.length > 0){
    this.setState({currentSelection: text});
  } 
}

createLink(){
  let linkURL = prompt('Enter a URL:', 'http://');
  if(linkURL!=null){
    try{
      document.execCommand('createlink', false, linkURL);
    }
    catch(err){
      console.log(err);
    }
  }
}

deleteLink(){
 if(this.state.currentSelection.length > 0){
  try{
    document.execCommand('unlink');
  }
  catch(err){
    console.log(err);
  } 
 }
}

fontStyle(event){
  let style = event.target.value !== undefined ? event.target.value.toString() : event.target.parentNode.value.toString();
  if(this.state.currentSelection !==''){
    try{
         document.execCommand(style);
    }
    catch(err){
      console.log(err);
    }
  }
}

getEditorValue(event){
  this.setState({editorValue: event.target.innerHTML});
  this.props.handleState('templateBody', event.target.innerHTML);
}

updateEditorValue(info, templateName){
  this.setState({editorValue: info.body});
  if(templateName === '_blank'){
   let updateState = {'templateBody': info.body, body: null, ht:[], widgets:[], fromName: null, fromEmail: null, bcc:[], cc: [], subject:null}
   this.props.handleState(updateState, false);
  }
  else{
    this.props.handleState('templateBody', info.body);
    this.props.handleState(info, false);
  }
  this.deleteHtml();
  this.insertHtml(info.body);
}



setColor(event){
  let color = event.target.value.toString();
  if(color){
    try{
      document.execCommand('foreColor', false, color);
    }
    catch(err){
      console.log(err);
    }
  }
}

alignText(event){
  let val = event.target.value !== undefined ? event.target.value : event.target.parentNode.value;
  if(this.state.currentSelection.length > 0 && val !== ''){
     switch(val) {
        case 'center':
        document.execCommand('justifyCenter');
        break;

        case 'left':
        document.execCommand('justifyLeft');
        break;

        case 'right':
        document.execCommand('justifyRight');
        break;

        case 'justify':
        document.execCommand('justifyFull');
        break;

        default :
        document.execCommand('justifyLeft');
     } 
  }
}

wrappTable(event){
  let tag = event.target.value !== undefined ? event.target.value : event.target.parentNode.value;
  let html = '<div style="width:528px;overflow-x:auto;margin:0 auto;">'+tag+'</div>';
  this.insertHtml(html);
}

setFontFamily(event){
  let font= event.target.value.toString();
  if(font){
    try{
      document.execCommand('fontName', false, font);
    }
    catch(err){
      console.log(err);
    }
  }
}

insertList(event){
    let listType = event.target.value !== undefined ? event.target.value : event.target.parentNode.value;
    try{
      document.execCommand(listType);
    }
    catch(err){
      console.log(err);
    }
  
}


getPaste(event){

  //check if is an excell table
  let toReg = event.clipboardData.getData('text/html');
  // regexp
  toReg = toReg.replace(/(\r\n|\n|\r)/gm,"");
  //var regstyle = /<STYLE*>.*<\/STYLE>/gi;
  let reg = /<TABLE.*>.*<\/TABLE>/gi;
  //var styleCode = toReg.match(regstyle);
  let tableCode = toReg.match(reg); 
  if(tableCode !== null){
    event.preventDefault();
    let finalCode = toReg.replace('body,div,table,thead,tbody,tfoot,tr,th,td,p','#xxx');
    //finalCode = finalCode.replace(/pt;/g,'px;');
    try{
      //document.execCommand('insertText', true, tableCode);
      this.insertHtml(finalCode);
      return;
    }
    catch(err){
      console.log(err);
    }

  }
  else{
    if(!this.state.htmlTags){//remove all html tags
      event.preventDefault();
      let data = event.clipboardData ? event.clipboardData.getData('text/plain') : window.clipboardData.getData('Text');
      try{
        document.execCommand('insertText', false, data.replace(/(<([^>]+)>)/ig,""));
      }
      catch(err){
        console.log(err);
      }
    }
  }
}


unFocus(){
  ReactDOM.findDOMNode(this.refs.txteditor).blur();
}




  render() {
    return (
      <div id="draftContentEditor" className="flex-item">
         <TemplateManagerMenu updateTemplateInfo={this.updateEditorValue.bind(this)} handleState={this.props.handleState} returnComponentState={this.props.returnComponentState} />
         <div className="row">
         <nav className="flex textEditorMenu">
          <button onClick={this.createLink.bind(this)} title="Create link" className="txtEditorAction">
           <i className="fa fa-link"></i>
          </button>
          <button onClick={this.deleteLink.bind(this)} title="Unlink" className="txtEditorAction">
           <i className="fa fa-unlink"></i> 
          </button>
          <button onClick={this.fontStyle.bind(this)} value="italic" title="Text Italic" className="txtEditorAction">
           <i className="fa fa-italic"></i> 
          </button>
          <button onClick={this.fontStyle.bind(this)} value="bold" title="Text Bold" className="txtEditorAction">
           <i className="fa fa-bold"></i> 
          </button>
          <button onClick={this.fontStyle.bind(this)} value="underline" title="Underlined Text" className="txtEditorAction">
           <i className="fa fa-underline"></i>
          </button>
          <button onClick={this.fontStyle.bind(this)} value="strikeThrough" title="Strikethrough" className="txtEditorAction">
           <i className="fa fa-strikethrough"></i>
          </button>
          <button onClick={this.setSize.bind(this)} value="fontSize" title="Font size" className="txtEditorAction">
           <i className="fa fa-superscript"></i>
          </button>
          <button onClick={this.createHtml.bind(this)} value="html" title="Html code" className="txtEditorAction">
           <i className="fa fa-code"></i>
          </button>
          <button onClick={this.wrappTable.bind(this)} value="[table]" title="Wrapp table" className="txtEditorAction">
           <i className="fa fa-th"></i>
          </button>
          <button onClick={this.insertList.bind(this)} value="insertorderedlist" title="Insert orderd list" className="txtEditorAction">
           <i className="fa fa-list-ol"></i>
          </button>
          <button onClick={this.insertList.bind(this)} value="insertunorderedlist" title="Insert unorderd list" className="txtEditorAction">
           <i className="fa fa-list"></i>
          </button>

          <div title="Text Color" className="colorFiled formatTxtBtn txtEditorAction">
           <i className="fa fa-paint-brush"></i> 
           <input type="color" onChange={this.setColor.bind(this)} className="transparent"/>
          </div>
         </nav>
         <nav className="flex textEditorMenu">

         <button onClick={this.alignText.bind(this)} value="center" title="Align center" className="txtEditorAction">
           <i className="fa fa-align-center"></i>
          </button>

          <button onClick={this.alignText.bind(this)} value="left" title="Align left" className="txtEditorAction">
           <i className="fa fa-align-left"></i>
          </button>

          <button onClick={this.alignText.bind(this)} value="right" title="Align right" className="txtEditorAction">
           <i className="fa fa-align-right"></i>
          </button>

          <button onClick={this.alignText.bind(this)} value="justify" title="Justify" className="txtEditorAction">
           <i className="fa fa-align-justify"></i>
          </button>
          <div className="custom-select-box">
          <select onChange={this.setFontFamily.bind(this)}>
            <option value="Arial">Font Family</option>
            <option value="Arial, Helvetica, sans-serif">Arial, Helvetica, sans-serif</option>
            <option value="Arial Black, Gadget, sans-serif">Arial Black, sans-serif</option>
            <option value="Comic Sans MS">Comic Sans MS</option>
            <option value="Geneva, sans-serif">Geneva</option>
            <option value="Impact, Charcoal, sans-serif">Impact</option>
            <option value="Tahoma, Geneva, sans-serif">Tahoma</option>
            <option value="Trebuchet MS, Helvetica, sans-serif">Trebuchet MS</option>
            <option value="Verdana, Geneva, sans-serif">Verdana</option>    
          </select>
         </div>
         <InsertTable returnComponentState={this.props.returnComponentState} onChange={this.insertHtml} />
        
         </nav>
        </div> 
        <div className="editorHolder">
         <Editor ref="txteditor" onPaste={this.getPaste.bind(this)} onChange={this.getEditorValue.bind(this)} onSelect={this.selectTxt.bind(this)} onKeyUp={this.getEditorValue.bind(this)} onBlur={this.unFocus.bind(this)} />
        </div>
         <Preloader showPreloader={this.state.showPreloader} />
      </div>
    );
  }


}