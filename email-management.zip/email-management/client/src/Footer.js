import React from 'react';
import NextComponentBtn from './components/NextComponentBtn';
import {setPreloaderStatus} from './actions/AppActions.js';
export default class Header extends React.Component {
  

    nextComponent(event){
      event.preventDefault();
      this.props.handleComponentState('activeComponent','EmailRecipients');
      setPreloaderStatus('show');
    }

    prevComponent(event){
      event.preventDefault();
      setPreloaderStatus('show');
      this.props.handleComponentState('activeComponent','TextEditor');
    }



   


    render() {
        return (
          <footer className="app-footer">
           <NextComponentBtn action={this.prevComponent.bind(this)} activecomponent={this.props.returnComponentState('activeComponent')} name="prev" id=""/>
           <NextComponentBtn action={this.nextComponent.bind(this)} activecomponent={this.props.returnComponentState('activeComponent')} name="next" id="f-right"/>
          </footer>
        );
      }


}