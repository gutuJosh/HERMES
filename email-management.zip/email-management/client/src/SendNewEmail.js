import React from 'react';
import { setPreloaderStatus } from './actions/AppActions.js';

export default class SendNewEmail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            emailStatus: {status : 400, message: ''}
        }
    }

    componentDidMount(){
        let mail = this.props.returnComponentState('wasEmailSend');
        if(mail.status === 200){
            this.setState({emailStatus: {status: mail.status, message: mail.message}});
        }
        this.setState({emailStatus: this.props.returnComponentState('wasEmailSend')});
        
    }


    handleClick(event){
        event.preventDefault()
        if(this.state.emailStatus.status === 200){
            this.props.handleState({ templateBody:'', body:'', ht:[], widgets:[], textBlocks: {content:'', name:''}, firma:'', nomeFirma:'', to:null, fromName: null, fromEmail:null, bcc:[], cc:[], subject: null, attachments:null, wasEmailSend: null}, false);
        }
        this.props.handleState({activeComponent: 'TextEditor'});
    }

    reloadComponent(event){
        event.preventDefault();
        setPreloaderStatus('show');
        this.props.handleState({activeComponent: 'EmailRecipients'});
    }

    render() {
        
        return (
            <div className="flex-item" id="draftContentEditor">
             <div className="row send-new-email-container">
              <div className="send-new-email text-center">
             { this.state.emailStatus.status === 200 ?
              <div className="mtop10">
               <h2>Your email was sent successfully!</h2>
               <p>Status {this.state.emailStatus.message}</p>
              </div>  
              :
              <div className="mtop10">
               <h2>An error has occured!</h2>
               <p className="text-red">Error: {JSON.stringify(this.state.emailStatus.message)}</p>
              </div>
            }
        
             <div className="coll-full text-center pad5 mtop10">
             { this.state.emailStatus.status === 200 ? 
              <button onClick={this.handleClick.bind(this)} className="new-email-btn">Compose new email</button>
              :
              <button onClick={this.reloadComponent.bind(this)} className="new-email-btn">Reload <i className="fa fa-refresh"></i></button>
             }
             </div>

            </div>
           </div>
         </div>
        );

    };
}