import React from 'react';


export default class SelectTemplates extends React.Component {
    constructor(props) {
       super(props);
       this.state = {
         templates: [],
         activeTemplate: null
       }
    }

    componentWillMount(){
        let self = this;
        let url = this.props.componentName === 'body' ? '/templatemanager/gettemplates/?language=' : '/templatemanager/readdir/'+this.props.componentName+'/?language=';
        fetch(url + encodeURIComponent(this.props.returnComponentState('language')))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.setState({templates:data[0].items});
              }
              else{
                  console.log(data[0].status);
              }
           });
         });    
    }

   

    componentDidMount(){
      let query = this.props.returnComponentState('query');
      if(query !== null){
        if(this.props.componentName === 'body' && query.type !== null){
         this.setState({activeTemplate:query.type});
        }
        else if(this.props.componentName === 'firma' && query.sign !== null){
            this.setState({activeTemplate:query.sign});
         } 
      }
     
    }

    componentDidUpdate(prevProps){
      
      if(prevProps !== this.props){ 
        if(this.props.returnComponentState(this.props.componentName) !=='' && this.props.returnComponentState(this.props.componentName) !== null){
          this.setState({selectedItems:1});
      }
     }
    }


  handleChange(event){
    event.preventDefault();
    this.props.loadTemplate(event.target.value);
    if(event.target.value === '_blank'){
      this.setState({activeTemplate: null});
    }
    else{
      this.setState({activeTemplate:event.target.value.replace('.html','')});
    }
  }


  setFirmaPosition(event){
    event.preventDefault();
  
    let element = event.target.tagName === 'a' ? event.target.firstChild : event.target;
    if(element.classList.contains('fa-check-square-o')){
      element.classList.remove('fa-check-square-o');
      element.classList.add('fa-square-o');
      this.props.setComponentState('firmaPosition','before');
    }
    else if(element.classList.contains('fa-square-o')){
      element.classList.remove('fa-square-o');
      element.classList.add('fa-check-square-o');
      this.props.setComponentState('firmaPosition','end');
    }

  }



    render() {

     let activeTemplate = this.props.defaultValue !== undefined ? this.props.defaultValue : this.state.activeTemplate;
      
      return (
        <div className="custom-select-box">
         <div className="block">
         { this.state.activeTemplate !== null &&
             <span className="badge badge-right badge-blue" title={activeTemplate}>1</span>
          }
          <input type="checkbox" id={"select-"+this.props.componentName} className="btn" value="off"/>
          <label htmlFor={"select-"+this.props.componentName} className="select-btn pointer">{this.props.title}</label>
           <ul className={"select-"+this.props.componentName}>
              <li>

                 <label  className="pointer inline-block">Signature at bottom
                 { this.props.componentName === 'firma' &&
                  <a className="f-right text-sky inline-block" title="Set signature at the bottom" href="/" onClick={this.setFirmaPosition.bind(this)}>
                   <i className="fa fa-check-square-o"></i>
                  </a>
                  }
                  </label>
                
              </li>
               <li>
                 <input type="radio" value="_blank" className={"input-"+this.props.componentName+'[]'}  id={this.props.componentName+'_blank'}  name={'input-'+this.props.componentName+'[]'} onChange={this.handleChange.bind(this)}/>
                 <label htmlFor={this.props.componentName+'_blank'} className="pointer inline-block">Blank</label>
                </li> 
             { this.state.templates.map((item, i) => (
                <li key={i}>
                 <input type="radio" name={'input-'+this.props.componentName+'[]'} checked={activeTemplate === item.replace('.html','')} value={item} className={"input-"+this.props.componentName}  id={item.replace('.html','')}  onChange={this.handleChange.bind(this)}/>
                 <label htmlFor={item.replace('.html','')} className="pointer inline-block">{item.replace('.html','')}</label>
                </li> 
              ))}
            </ul>
            </div>
        </div>
      );
    }
  };