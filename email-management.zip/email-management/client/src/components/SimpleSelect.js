import React from 'react';


const SimpleSelect = function (props) { 

      const handleChange = function(event){
          props.handleChange(event.target.value);
      }
     
      return (
        <div className="custom-input mtop10">
         <select className="select-box" onChange={handleChange} name={props.name}>
           <option value="">Select template</option>
           {props.templates.map((item, i) => (
            <option key={i} value={item}>{item}</option>
           ))}
          </select>
        </div>
      );
    
  };
  export default SimpleSelect;