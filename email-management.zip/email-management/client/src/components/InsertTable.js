import React from 'react';

export default class InsertTable extends React.Component {
    constructor(props) {
       super(props);
       this.state = {
         tableTemplates:[]
       }
       this.handleChange = this.handleChange.bind(this)
    }

    componentWillMount(){
        var self = this;
        fetch('/templatemanager/readdir/tb/?language='+encodeURIComponent(this.props.returnComponentState('language')))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.setState({tableTemplates:data[0].items});
              }
              else{
                  console.log(data[0].status);
              }
           });
        });
    }

   

  handleChange(event){
    event.preventDefault();
    if(event.target.value === '_blank'){
      return false;
    }
    var templateName = event.target.value.replace('.html','');
    var self = this;
        fetch('/templatemanager/readfile/tb/'+templateName+'/?language='+encodeURIComponent(this.props.returnComponentState('language')))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                self.props.onChange(data[0].content.content);
              }
              else{
                  console.log(data[0].status);
              }
           });
        });
  }


    render() {

      return (
        <div className="custom-select-box">
             <select name="insertTemplates" onChange={this.handleChange}>
              <option value="_blank">Insert tb</option>
              { this.state.tableTemplates.map((item, i) => (
                <option key={i} value={item}>{item.replace('.html','')}</option> 
              ))}
             </select>
        </div>
      );
    }
  };