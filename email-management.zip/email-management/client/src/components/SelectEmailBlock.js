import React from 'react';


const SelectEmailBlock = function (props) { 
  
     const activeItems = props.activeItems;
      return (
        <div className="custom-select-box">
          <div className="block">
            {props.activeItems.length > 0 &&
             <span className="badge badge-right badge-blue" title={activeItems.join(',')}>{props.activeItems.length}</span>
            }
             <input type="checkbox" id={"select-"+props.componentName} className="btn" value="off"/>
             <label htmlFor={"select-"+props.componentName} className="select-btn pointer">Select {props.componentName}</label>
             <ul className={"select-"+props.componentName}>
              { props.templates.map((item, i) => (
                <li key={i}>
                 <input type="checkbox" checked={activeItems.indexOf(item.replace('.html','')) !== -1} value={item} className={"input-"+props.componentName} data-name={props.componentName} id={item.replace('.html','')}  onChange={props.handleChange}/>
                 <label htmlFor={item.replace('.html','')} className="pointer inline-block">{item.replace('.html','')}</label>
                 {activeItems.indexOf(item.replace('.html','')) !== -1 ?
                 <input type="text" name={props.componentName} onInput={props.handleComponentOrder} data-id={item.replace('.html','')} className="order-email-blocks text-center" maxLength="1" key={activeItems.indexOf(item.replace('.html',''))} defaultValue={(activeItems.indexOf(item.replace('.html',''))+1)}/>
                 :
                 <input type="text" name={props.componentName} onInput={props.handleComponentOrder} data-id={item.replace('.html','')} className="order-email-blocks text-center" maxLength="1" />
                 }
                </li> 
              ))}
             </ul>
          </div>
        </div>
      );
    
  };
  export default SelectEmailBlock;