import React from 'react';


const RadioBtn = function (props) { 

      const handleChange = function(event){
          if(event.target.value !== ''){
            props.handleChange(event.target.value);
          }
      }
     
      return (
        <label className={"custom-radio-btn inline-block "+props.disabled}>
            {props.text}
            <input type="radio" value={props.value} name={props.name} disabled={props.disabled !== ''} onChange={handleChange}/>
            <span className="radio-checkmark"></span>
        </label>
      );
    
  };
  export default RadioBtn;