import React from 'react';


const SimpleInputField = function (props) { 

      const handleChange = function(event){
          if(event.target.value !== ''){
            props.handleChange(event.target.value);
          }
      }

      const blur = function(event){
        if(event.target.value === ''){
          props.onBlur('');
        }
      }
     
      return (
        <div className="custom-input mtop10">
          <input type="text" className="pad5" name={props.name} defaultValue={props.defaultValue} placeholder={props.placeholder} onBlur={blur} onInput={handleChange} />
        </div>
      );
    
  };
  export default SimpleInputField;