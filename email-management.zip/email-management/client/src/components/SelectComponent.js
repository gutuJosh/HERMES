import React from 'react';


const components = {'TextEditor' : 'Compose email', 'TemplateSettings': 'Template settings', 'TemplateEditor': 'Template editor'};

const SelectComponent = function (props) { 
  
      let componentName = props.componentName;

      if(componentName !== 'TextEditor' && !components.hasOwnProperty(componentName)){
          componentName = 'TextEditor';
      }

      return (
        <div className="custom-select-box f-right" id="main-components-selector">
          <div className="block">
             <input type="checkbox" id={"select"+componentName} className="btn main-components-selector" value="off" />
             <label htmlFor={"select"+componentName} className="select-btn pointer">{components[componentName]}</label>
             <ul className={"select-"+props.componentName}>
              { Object.keys(components).map((item, i) => (
                <li key={i}>
                 <input type="checkbox" value={item}  className="select-main-component" id={item}  onChange={props.handleComponents}/>
                 <label htmlFor={item} className="pointer inline-block">
                  <span>{components[item]}</span>
                 </label>
                </li> 
              ))}
             </ul>
          </div>
        </div>
      );
    
  };
  export default SelectComponent;