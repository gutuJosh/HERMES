import React from 'react';

export default class InputFiled extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
       visibleValue: '',
       errors: null
    }
    this.handleInput = this.handleInput.bind(this);
    this.updateVisibleValue = this.updateVisibleValue.bind(this);
    this.checkInputValue = this.checkInputValue.bind(this);
  }

  componentDidMount(){
    this.setState({visibleValue:this.props.defaultValue});
  }

  updateVisibleValue(event){
     this.setState({visibleValue:event.target.value});
  }

  handleInput(event){
    event.preventDefault();
    let val = event.target.value.trim();
    let componentName = this.props.name;
    if(val === '' && (componentName === 'to' || componentName === 'fromEmail' || componentName === 'subject')){
      this.setState({errors:'This is a mandatory field and shall be filled in', visibleValue:''});
    }

    if(componentName === 'bcc' && val !== ''){
      val = val.replace(/ /g, '');
      let bcc = val.split(',');
      for(let i = 0; i < bcc.length; i++){
          if(bcc[i].indexOf('.') === -1 || bcc[i].indexOf('@') === -1){
            this.setState({errors:'Invalid email address', visibleValue:''});
            event.target.value = '';
            break;
          }
      }
    }

    if(componentName === 'cc' && val !== ''){
      val = val.replace(/ /g, '');
      let cc = val.split(',');
      for(let i = 0; i < cc.length; i++){
          if(cc[i].indexOf('.') === -1 || cc[i].indexOf('@') === -1){
            this.setState({errors:'Invalid email address', visibleValue:''});
            event.target.value = '';
            break;
          }
      }
    }

    if(componentName === 'to' || componentName === 'fromEmail'){
      if(val.indexOf('.') === -1 || val.indexOf('@') === -1){
          this.setState({errors:'Invalid email address', visibleValue:''});
          event.target.value = '';
      }
    }
    this.props.handleInput(componentName, val);
  }


  checkInputValue(event){
    event.preventDefault();
    if(this.state.errors !== null){
       this.setState({errors: null});
    }
  }

     
  render() {
     let errorClass = this.state.errors !== null ? ' error' : '';
     
      return (
       <div className="row custom-input mtop10">
         <div className="col-lg-2 col-md-3 col-sm-4 text-left pad5">
            <label>{this.props.title}:</label>
         </div>
         <div className="col-lg-10 col-md-9 col-sm-8 pad5">
            <input type="text" className={"pad5"+errorClass} name={this.props.name} defaultValue={this.props.defaultValue} placeholder={this.props.placeholder} onInput={this.updateVisibleValue} onFocus={this.checkInputValue} onBlur={this.handleInput} />
            {this.state.errors === null ?
            <p>{this.state.visibleValue}</p>
            :
            <p className="text-red">{this.state.errors}</p>
            }
        </div>
       </div>
      );
    }
    
  };


