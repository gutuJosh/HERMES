import React from 'react';


export default class ImputBox extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           visibleValue: '',
           errors: null,
           defaultvalue: this.props.defaultValue
        }
      }

    

     componentDidUpdate(prevProps){
        if(prevProps.defaultValue !== this.props.defaultValue){
            //*console.log(prevProps.defaultValue+'----->'+this.props.defaultValue);
            this.setState({defaultvalue: this.props.defaultValue, visibleValue: this.props.defaultValue});
        }   
     }


    updateVisibleValue(event){
        this.setState({visibleValue: event.target.value});
    }


    checkInputValue(event){
      
        event.preventDefault();
        if(this.state.errors !== null){
           this.setState({errors: null});
        }

        
    }

  handleInput(event){
        if(this.props.required && event.target.value === ''){
            this.setState({errors:'This is a mandatory field and shall be filled in', visibleValue:''});
            
        }
        else{
            this.props.handleInput(event.target.name, event.target.value);
        }
    }

     
    render() {
     let errorClass = this.state.errors !== null ? ' error' : '';

      return (
        <div className="row custom-input mtop10">
         <div className="col-lg-2 col-md-3 col-sm-4 text-left pad5">
            <label>{this.props.title}:</label>
         </div>
         <div className="col-lg-10 col-md-9 col-sm-8 pad5">
           {this.state.defaultvalue !=='' ?
            <input type="text" className={"pad5"+errorClass} name={this.props.name}  key={this.props.defaultValue || this.state.defaultvalue}  defaultValue={this.props.defaultValue || this.state.defaultvalue} title={this.props.placeholder} onInput={this.updateVisibleValue.bind(this)} onFocus={this.checkInputValue.bind(this)} onBlur={this.handleInput.bind(this)} />
            :
            <input type="text" className={"pad5"+errorClass} name={this.props.name}  placeholder={this.props.placeholder} title={this.props.placeholder} onInput={this.updateVisibleValue.bind(this)} onFocus={this.checkInputValue.bind(this)} onBlur={this.handleInput.bind(this)} />
           }
            {errorClass === '' ?
            <p>{this.state.visibleValue}</p>
            :
            <p className="text-red">{this.state.errors}</p>
            }
        </div>
       </div>
        
      );
    }
    
    
  };
