import React from 'react';


const Label = function (props) { 


     
      return (
        <div className={"col-full mbottom10 label "+props.type} onClick={props.action}>
            <p className="text-center">
             <i className="f-right pointer fa fa-remove"></i>
             {props.message}
            </p>
        </div>
      );
    
  };
  export default Label;