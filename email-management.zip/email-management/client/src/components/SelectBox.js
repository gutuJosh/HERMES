import React from 'react';

export default class SelectBox extends React.Component {
    constructor(props) {
       super(props);
       this.state = {
         templates: {},
         activeTemplate: ''
       }
    }

    componentWillMount(){
        let self = this;
        let url ='/templatemanager/getsettings/?language=';
        fetch(url + encodeURIComponent(this.props.language))
         .then(function(response){
            response.json().then(function(data) {
              if(data[0].status === 200){
                let initFile = data[0].initFile;
                Object.keys(initFile).forEach(function(obj){
                    initFile[obj].name = obj;
                });

                self.setState({templates:initFile});
              }
              else{
                  console.log(data[0].status);
              }
           });
         });    
    }

    componentDidMount(){
     
    }
   

    componentDidUpdate(prevProps){
      if(prevProps.value !== this.props.value){
          if(this.props.value !== null){
            let initFile = this.state.templates;
            let newValue = this.props.value;
            Object.keys(initFile).forEach(function(obj){
                if(initFile[obj].name === newValue.name){
                  initFile[obj] = newValue;
                }
            });
            this.setState({templates: initFile, activeTemplate: this.props.value});
          }
          else{
            this.setState({activeTemplate: ''});
            this.props.handleChange('');
          }
      }   
   }

   handleChange(event){
     event.preventDefault();
     this.props.handleChange(event.target.value);
   }





    render() {

      return (
        <div className="row mtop10">
          <div className="col-full">
          <select className="select-box" onChange={this.handleChange.bind(this)}>
           <option value="" selected={this.state.activeTemplate === ''}>Select template</option>
           {Object.keys(this.state.templates).map((item, i) => (
            <option key={i} value={JSON.stringify(this.state.templates[item])}>{item}</option>
           ))}
          </select>
          </div>
        </div>
      );
    }
  };