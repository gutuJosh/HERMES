import React from 'react';


const Preloader = function (props) { 
     
      return (
        <div className={"preloader text-azure "+props.showPreloader}>
            <i className="fa fa-spinner fa-pulse fa-3x fa-fw margin-bottom"></i>
        </div>
      );
    
  };
  export default Preloader;