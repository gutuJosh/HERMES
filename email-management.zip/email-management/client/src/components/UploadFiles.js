import React from 'react';
import axios from 'axios';
import {setPreloaderStatus} from '../actions/AppActions.js';

export default class UploadFiles extends React.Component {
    constructor(props) {
       super(props);
       this.state = {
         files: []
       }
       this.uploadAttachment = this.uploadAttachment.bind(this);
       this.deleteAttachment = this.deleteAttachment.bind(this);
    }





    componentWillMount(){
       
        //check for attachments
        /*let self = this;
        axios.get('/sendmail/getattachments')
        .then(function(response){
            if(response.data.status === 200 && response.data.attachments.length > 0){
                self.setState({files:response.data.attachments});
            }
        });*/
        let attachments = this.props.returnComponentState('attachments');
        if(attachments !== null){
          this.setState({files:attachments});
        }
    }

  

   


    uploadAttachment(event){
        event.preventDefault();
        var self = this;
        if(event.target.files[0] === undefined){
            return false;
        }
        let fileName = event.target.files[0].name;
        setPreloaderStatus('show');
        /*var fileName = event.target.files[0].name;
        var reader = new FileReader();
        reader.onload = function(){
         var dataURL = reader.result.split(';base64,');
         dataURL = dataURL[1];
         self.props.handleComponentState('attachments',JSON.stringify({data:dataURL, name:fileName}));
       };
       console.log(event.target.files[0].name);
       reader.readAsDataURL(event.target.files[0]);*/
        let formData = new FormData();
        formData.append('attachments', event.target.files[0])
        const config = {
            headers: { 'content-type': 'multipart/form-data' }
        }
      
       axios.post('/sendmail/attachment', formData, config)
            .then(function (response) {
              if(response.data.status === 200 && response.data.message === 'File uploaded successfully'){
                let filenames = self.state.files;
                filenames.push(fileName);
                self.setState({files: filenames});
                self.props.handleState('attachments',filenames);
                setPreloaderStatus('hidden');
              }
            
            }).catch(function (error) {
              console.log(error);
              setPreloaderStatus('hidden');
             });
      }


    deleteAttachment(event){
        event.preventDefault();
        setPreloaderStatus('show');
        let self = this;
        let fileToDelete = event.target.value;
        //console.log(fileToDelete);
        axios.post('/sendmail/attachment/delete',
        {
          attachmentName: encodeURIComponent(fileToDelete),
        }
        ).then(function (response) {
            if(response.data.status === 200 && response.data.message === 'Attachment was deleted successfully'){
                let filenames = self.state.files;
                for(let i = 0; i < filenames.length; i++){
                     
                     if(filenames[i] === fileToDelete){
                        filenames.splice(i, 1);
                        break;
                     }
                }
                self.setState({files: filenames});
                self.props.handleState('attachments',filenames);
                setPreloaderStatus('hidden');
            }
            
        }).catch(function (error) {
            console.log(error);
            setPreloaderStatus('hidden');
        });
 
    }


    render() {
        return (
          <div className="row"> 
           <div className="col-lg-2 col-md-3 col-sm-4 text-left pad5">
            <label>Files:</label>
            </div>
            <div className="col-lg-10 col-md-9 col-sm-8 pad5">
             <div className="custom-upload-box" data-txt="Add an attachment">
              <input type="file" className="transparent" name="attachment" onChange={this.uploadAttachment}/>
             </div>
             <ul className="attachments">
                { this.state.files.map((item, i) => (
                    <li key={i} className="inline-block mtop10">
                    <input type="checkbox" id={item.replace(/' '/g,'-')} value={item} onChange={this.deleteAttachment}/>
                    <label htmlFor={item.replace(/' '/g,'-')} className="pointer">{item}</label>
                    </li> 
                ))} 
             </ul>
            </div>
          </div>
        );
      }
    };