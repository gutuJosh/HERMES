import React from 'react';


export default class SelectLanguage extends React.Component {
    constructor(props) {
       super(props);
       this.state = {
         languages: [],
         languageName: {'it': 'Italiano', 'en': 'English', 'es': 'Espanol', 'fr': 'Français'}
       }
    }

    componentWillMount(){
        let self = this;
        fetch('/language/getlanguages')
         .then(function(response){
            response.json().then(function(data) {
              
              if(data.status === 200){
                self.setState({languages:data.languages});
              }
              else{
                  console.log(data[0].status);
              }
           });
         });    
    }

    handleChange(event){
       event.preventDefault();
       window.location = '?lang='+encodeURIComponent(event.target.value);
    }

     render() {
     let lang = this.state.languageName;
     
      return (
        <div className="f-right selectLanguage">
          <input type="checkbox" id="selectLanguage" value={this.props.activeLanguage} />
          <label htmlFor="selectLanguage" title="Select language" className="inline-block">
           <img src={"/images/"+this.props.activeLanguage+'.png'} alt="flag"  className="inline-block pointer"/>
           <i className="fa fa-caret-down"></i>
          </label>
          <ul className="language-options">
             
              { this.state.languages.map((item, i) => (
                <li key={i}>
                 <input type="radio" name="language[]" id={"select-"+item} value={item} onChange={this.handleChange.bind(this)}/>
                 <label htmlFor={"select-"+item}>
                  <img src={"/images/"+item+'.png'} alt="flag" width="20" height="15" title={lang[item]} className="pointer"/>
                 </label>
                </li>
              ))}
             </ul>
        </div>
      );
    }
  };