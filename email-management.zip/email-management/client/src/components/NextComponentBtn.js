import React from 'react';


const nextComponentBtn = function (props) { 
     
      let _style = props.name === 'next' ? {float:'right'} : {};
      let _disabled = ((props.name === 'next' && props.activecomponent === 'TextEditor') || (props.name === 'prev' && props.activecomponent !== 'TextEditor')) ? false : true;
     
      return (
            <button onClick={props.action} className={"footer-navigation-btn "+props.clasa} disabled={_disabled} style={_style}>
             {props.name !== 'next' ? 
              <span>
               <i className="fa fa-angle-left"></i> Back
              </span>
              :
              <span>
               Next <i className="fa fa-angle-right"></i>
              </span>
             }
            </button>
        
      );
    
  };
  export default nextComponentBtn;