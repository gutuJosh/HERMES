import React from 'react';
import Label from './components/Label';
import InputField from './components/InputField';
import UploadFiles from './components/UploadFiles';
import Preloader from './components/Preloader';
import AppStore from './stores/AppStore.js';
import { setPreloaderStatus } from './actions/AppActions.js';

export default class EmailRecipients extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            to: null,
            fromName: null,
            fromEmail: null,
            bcc: [],
            cc: [],
            subject: null,
            attachments:null,
            preloaderStatus: 'hidden',
            formStatus: null
        }
        this.handleInputValue =  this.handleInputValue.bind(this);
        this._onPreload = this._onPreload.bind(this);
        this.sendMyEmail = this.sendMyEmail.bind(this);
    }

    componentWillMount(){
        AppStore.addChangeListener(this._onPreload);
        for (var key in this.state) {
              this.setState({[key] : this.props.returnComponentState(key)});
        }
        this.setState({'showPreloader' : AppStore.getPreloaderStatus()});
        
    }

    componentWillUnmount() {
        AppStore.removeChangeListener(this._onPreload);
    }

    componentDidMount(){
        setTimeout(
            function(){
                setPreloaderStatus('hidden');
            }, 500);

    }

    _onPreload(status){
        this.setState({'showPreloader' : AppStore.getPreloaderStatus()});
    }


    handleInputValue(componentName, value){
        this.setState({[componentName] : value});
        this.props.handleState(componentName, value);
    }

    sendMyEmail(event){
        event.preventDefault();
        //check if all fileds are filled corectly and promt an error message
        if(
            this.state.to === null || this.state.to === '' || 
            this.state.to.indexOf('.') === -1 || this.state.to.indexOf('@') === -1 ||
            this.state.fromName === null || this.state.fromName === '' || 
            this.state.fromEmail === null || this.state.fromEmail === '' || 
            this.state.fromEmail.indexOf('.') === -1 || this.state.fromEmail.indexOf('@') === -1 || 
            this.state.subject === null || this.state.subject === ''
          ){
            this.setState({'formStatus' : 'KO'});
            let self = this;
            setTimeout(function(){
                self.closeLabel.bind(self)();
            },3000);
            return;
        }
        else{
          this.props.sendAction();//send the message 
          return;
        }
    }
  
    closeLabel(){
        if(this.state.formStatus === 'KO'){
            this.setState({'formStatus': null});  
        } 
    }

    render() {
        
        return (
          <div id="draftContentEditor" className="flex-item email-recipients">
           <div className="row email-recipients-field-holder">
            <div className="col-full">
             <h1>Recipients</h1>
             <p>
                  You're one step away from sending your awesome e-mail,
                  fill in all mandatory fields and click Send Email button
             </p>
             <hr/>
            </div>
            {this.state.formStatus === 'KO'  &&
             <Label type="label-error" message="Please fill in all fileds marked with *" action={this.closeLabel.bind(this)}/>
            }
            <InputField title="*to" name="to" placeholder="Insert email recipient" defaultValue={this.state.to} handleInput={this.handleInputValue}/>
            <InputField title="*from" name="fromEmail" placeholder="Insert email address" defaultValue={this.state.fromEmail} handleInput={this.handleInputValue}/>
            <InputField title="*from name" name="fromName" placeholder="Insert name" defaultValue={this.state.fromName} handleInput={this.handleInputValue}/>
            <InputField title="bcc." name="bcc" placeholder="Insert email address" defaultValue={this.state.bcc} handleInput={this.handleInputValue}/>
            <InputField title="cc." name="cc" placeholder="Insert email address" defaultValue={this.state.cc} handleInput={this.handleInputValue}/>
            <InputField title="*Subject" name="subject" placeholder="Insert subject" defaultValue={this.state.subject} handleInput={this.handleInputValue}/>
            <UploadFiles handleState={this.props.handleState} returnComponentState={this.props.returnComponentState}/>
            <hr/>
            <div className="row mtop10">
            {this.state.formStatus === 'KO'  &&
             <Label type="label-error" message="Please fill in all fileds marked with *" action={this.closeLabel.bind(this)}/>
            }
            <div className="col-lg-12 col-md-12 col-sm-12 text-center pad5">
             <button onClick={this.sendMyEmail} className="send-email-btn inline-block">Send email</button>
            </div>
           </div>
          </div>
          <Preloader showPreloader={this.state.showPreloader} />
         </div>
        );
      }


}