var express = require('express');
var router = express.Router();
var path = require("path");
var fs = require("fs");
var tmpManager = require('../lib/templateManager.js');
var templateManager = new tmpManager();





/* load  template + email info. */
router.post('/', function(req, res, next) {
 
   if(!req.body.templateName){
	 next();
   }
    var language = decodeURIComponent(req.body.language).substring(0, 2);
	var info = templateManager.initTemplate(language, decodeURIComponent(req.body.templateName));
	
	//overwrite firma
	if(req.body.nomeFirma !== undefined && req.body.nomeFirma !== null && req.body.nomeFirma.length > 0){
	  var firma = templateManager.getBlock(language, 'firma', req.body.nomeFirma.replace('.html','')); 
	  if(firma !== false){
		  info.firma = firma;
	  }
	} 
	var status = !info ? 404 : 200;
	res.json([{
		status: status,
		info: info
	  }
	  ]);
  
	
  
});



/* GET template header and footer. */
router.get('/getsettings', function(req, res, next) {
	
	if(req.session['language'] == undefined){
		req.session['language'] = decodeURIComponent(req.query.language).substring(0,2);
	}
   //get current date
 
   var init = templateManager.getSettings(req.session['language']); 
   var status = init !== false ? 200 : 404;
   res.json([{
	   status: status,
	   initFile: init
	 }
	 ]);
 
});



/* GET template header and footer. */
router.get('/layout', function(req, res, next) {
    req.session['language'] = decodeURIComponent(req.query.language).substring(0,2);
	//get current date
	var date = new Date();
	var header = templateManager.getBlock(req.session['language'], 'layout', 'header'); 
	header = header !== false ? header.replace('[data]',date.getDate()+'-'+(date.getMonth() + 1)+'-'+date.getFullYear()) : header;
	var footer = templateManager.getBlock(req.session['language'], 'layout', 'footer');
	var status = (header !=false && footer != false) ? 200 : 404;
	res.json([{
		status: status,
		header: header,
		footer: footer
	  }
	  ]);
  
});

/* read template directory and return content. */
router.get('/gettemplates', function(req, res, next) {
	if(req.session['language'] == undefined && !req.query.language){
		res.json([{
			status: 400,
			message:'Language parameters is missing'
		  }
		  ]);
	}

	if(req.session['language'] == undefined){
		req.session['language'] = decodeURIComponent(req.query.language).substring(0,2);
	}
	
	var content = templateManager.getTemplates(req.session['language']);
	var status = content != false ? 200 : 404;
	res.json([{
		status: status,
		items: content
	  }
	  ]);



});



router.get('/readdir/:dirname', function(req, res, next) {
   
	if(!req.params.dirname){
		next();
	}

	if(req.session['language'] == undefined){
         req.session['language'] = decodeURIComponent(req.query.language).substring(0,2);
    }

	var content = templateManager.scanDir(req.session['language'], req.params.dirname);
	var status = content != false ? 200 : 404;
	res.json([{
		status: status,
		items: content
	  }
	  ]);
  
});


/* read template file and return html content. */
router.get('/readfile/:dirName/:filename', function(req, res, next) {

	if(!req.params.dirName || !req.params.filename){
		next();
	}
	
    req.session['language'] = decodeURIComponent(req.query.language).substring(0,2);

	var content = {content: templateManager.getBlock(req.session['language'], req.params.dirName, req.params.filename), name:req.params.filename};
	var status = content != false ? 200 : 404;
	res.json([{
		status: status,
		content: content
	  }
	  ]);
  
});


/*edit templates*/
router.post('/edit/:action/:dirName/:filename', function(req, res, next) {
    
	if(!req.body.language || !req.params.action || !req.params.dirName || !req.params.filename){
	  next();
	}
     var errors='';
	 var action = decodeURIComponent(req.params.action);
	 var language = decodeURIComponent(req.body.language).substring(0, 2);
	 var message = decodeURIComponent(req.body.message);
	 var dir = decodeURIComponent(req.params.dirName);
	 var fileName = decodeURIComponent(req.params.filename);

	if(action === 'delete'){ 
		var url = "public/templates/"+language+"/"+dir+'/'+fileName;
		fs.unlink(url, function (error) {
			if (error) {
				console.error(error.message);
				errors += error.message;
				res.json([{
					status: 400,
					message: errors
				}
				]);
			}
			else {
				var cachedFile = language+'-'+fileName.replace('.html','');
				templateManager.deleteCache(cachedFile);
				//delete from config init file if is a body template
				if(dir === 'body'){
					var delFile = templateManager.deleteTemplate(language, fileName.replace('.html',''));
				}
			
				res.json([{
					status: (dir === 'body' && delFile !== 'OK') ? 400 : 200,
					message: (dir === 'body' && delFile !== 'OK') ? JSON.stringify(delFile) : "The file "+fileName+" was deleted!"
				}
				]);
			}
		    
		});
	}
	else if(action === 'new' || action === 'modify'){
		fileName = (action === 'new') ? fileName+'.html' : fileName;
		//if is a new file set file name correctly 
		if(action === 'new'&& dir !== 'body'){
			switch(dir) {
				case 'ht':
				fileName = 'ht-'+fileName.replace(/ht-/g,'');
				break;

				case 'firma':
				fileName = 'firma-'+fileName.replace(/firma-/g,'');
				break;

				case 'tb':
				fileName = 'tb-'+fileName.replace(/tb-/g,'');
				break;

				case 'widgets':
				fileName = 'widget-'+fileName.replace(/widget-/g,'');
				break;

				default:
				fileName = fileName;
			}
		}
		fs.writeFile("public/templates/"+language+"/"+dir+'/'+fileName, message, function(error) {
			if (error) {
			console.error(error.message);
			errors += error.message;
			res.json([{
				status: 400,
				message: errors
			}
			]);
			} else {
				//delete cache
				var cachedFile = language+'-'+fileName.replace('.html','');
				templateManager.deleteCache(cachedFile);
				//write in config file if is a new body template
				if(action === 'new'&& dir === 'body'){
				   let append = templateManager.appendTemplate(language, fileName.replace('.html',''));
				   if(append !== 'OK'){
					res.json([{
						status: 400,
						message: append
					}
					]);
				   }
				}
				
				res.json([{
					status: 200,
					message: (action === 'modify') ? "The file " +fileName+" was modified successfully!" : "The file "+fileName+" was created successfully!"
				}
				]);
				
			}
		});
	}	
	else{
		next();
	} 
   
 });


module.exports = router;
