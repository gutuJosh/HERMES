var express = require('express');
var router = express.Router();
var fs = require("fs");
var nodemailer = require('nodemailer');
var formidable = require('formidable');
var tmpManager = require('../lib/templateManager.js');
var templateManager = new tmpManager();
var replaceHtmlTags = require('../lib/replaceHtmlTags.js');

router.post('/attachment', function(req, res, next) {
  var form = new formidable.IncomingForm();
  form.parse(req, function(err, fields, files) {
    if(err){
      res.json({
        status: 200,
        message: err
      });
    }
    else{
      //console.log(files.attachments.name);

      if(req.session['attachments'] == undefined){
         req.session['attachments']=[];
      }

      req.session['attachments'].push({
        filename: files.attachments.name,
        content: fs.createReadStream(files.attachments.path)
      });

      res.json({
        status: 200,
        message: 'File uploaded successfully'
      });
    }
    /*fs.readFile(files.upload.path, function (err, data) {
      res.end(data);
    });*/
  }); 
});


router.post('/attachment/delete', function(req, res, next) {
  if(req.session['attachments'] == undefined){
    res.json({
      status: 400,
      message: 'No attachment was find'
    });
  } 
  else{
   var attachments = req.session['attachments'];
   for(let i = 0; i < attachments.length; i++){
        if(attachments[i].filename === decodeURIComponent(req.body.attachmentName)){
            attachments.splice(i,1);
            break;
        }
   }
   req.session['attachments'] = attachments;
   res.json({
    status: 200,
    message: 'Attachment was deleted successfully'
   });
  }
});

/* get all previous attachments*/
router.get('/getattachments', function(req, res, next) {
 
   if(req.session['attachments'] == undefined){
      res.json({
        status: 200,
        attachments: []
      });
   }
   else{
    var attachments = req.session['attachments'];
    var attachments_names = [];
    for(let i = 0; i < attachments.length; i++){
         attachments_names.push(attachments[i].filename);
    }
    res.json({
      status: 200,
      attachments: attachments_names,
      items:  req.session['attachments']
    });
   }
});

/* send email. */
router.post('/', function(req, res) {

    if(!req.body.message || req.body.message ==='' || !req.body.emailInfo || req.body.emailInfo === ''){
        res.json({
            status: 400,
            message: 'Message empty'
          });
    }
    else{
       try{//get smtp or gmail credentials
        var smtp_config = JSON.parse(fs.readFileSync("config/smtp.json"));
       }
       catch(err){
         //console.log(err);
         res.json({
          status: 400,
          message: 'Can\'t find credentials!'
        });
       }

       //if we dont have any credential 
       if(smtp_config.smtp.host === '' && smtp_config.auth.user === ''){
          res.json({
            status: 400,
            message: 'Missing credentials'
          });
          return;
       }

      //get current date
      var date = new Date();
      var language = 'en'; //decodeURIComponent(req.body.language);

      //get email header and footer
    	var header = templateManager.getBlock(language, 'layout', 'header').replace('[data]',date.getDate()+'-'+(date.getMonth() + 1)+'-'+date.getFullYear()),
          footer = templateManager.getBlock(language, 'layout', 'footer'),
          body = decodeURIComponent(req.body.message);
      
      //get ht, widgets, textBlocks and signature
      var _ht = [],
          _widgets = [],
          ht = JSON.parse(decodeURIComponent(req.body.emailInfo.ht)),
          widgets = JSON.parse(decodeURIComponent(req.body.emailInfo.widgets)),
          textBlocks = decodeURIComponent(req.body.emailInfo.textBlocks),
          firma = decodeURIComponent(req.body.emailInfo.firma);

        var htDynamicComponent = null;
        var widgetDynamicComponent = null;

        try{
          htDynamicComponent = req.body.dynamicComponent !== '' ? JSON.parse(decodeURIComponent(req.body.htDynamicComponent)) : null;
          widgetDynamicComponent = req.body.widgetDynamicComponent !== '' ? JSON.parse(decodeURIComponent(req.body.widgetDynamicComponent)) : null;
        }
        catch(err){
          console.log(err);
        }
       //asign highligted text values   
       for(let i = 0; i < ht.length; i++){
            let item = templateManager.getBlock(language, 'ht', ht[i]);
           
            if(item !== false){
                if(htDynamicComponent !== null && htDynamicComponent.type === 'ht' && htDynamicComponent.name === ht[i]){
                  let tags = JSON.parse(decodeURIComponent(htDynamicComponent.values));
                  _ht.push(replaceHtmlTags(item,tags));
                }
                else{
                 _ht.push(item);
                }
            }
       }
       //asign widgets values
       for(let i = 0; i < widgets.length; i++){
        let item = templateManager.getBlock(language, 'widgets', widgets[i].replace('.html',''));
        if(item !== false){
          if( widgetDynamicComponent !== null &&  widgetDynamicComponent.type === 'widgets' &&  widgetDynamicComponent.name === widgets[i].replace('.html','')){
            let tags = JSON.parse(decodeURIComponent(widgetDynamicComponent.values));
             _widgets.push(replaceHtmlTags(item,tags));
          }
          else{
           _widgets.push(item);
          }
        }
       } 
       //assign text blocks values
       textBlocks =  textBlocks !== '' ? templateManager.getBlock(language, 'tb', textBlocks) : '';

       let set_firma = templateManager.getBlock(language, 'firma', firma); 

       firma = (set_firma !== false) ? set_firma : '';
       
      
      //join email parts
      if(req.body.emailInfo.firmaPosition === 'end'){
         var emailTemplate = header + body + textBlocks + _ht.join('') + _widgets.join('') + firma + footer;
      }
      else{
        var emailTemplate = header + body + textBlocks + firma + _ht.join('') + _widgets.join('') + footer;
      }
      //use gmail account
      if(smtp_config.smtp.host === ''){ 
        var transporter = nodemailer.createTransport({
          service: smtp_config.service,
          auth: {
            user: smtp_config.auth.user,
            pass: smtp_config.auth.pass
          },
          debug:true
        });
      }
      else{//use smtp server
        var transporter = nodemailer.createTransport({
            host: smtp_config[language].host,
            port: smtp_config[language].port,
            secure:true, //use TLS
            auth: {
                user: smtp_config[language].username,
                pass: smtp_config[language].password
            },
            tls: {
              // do not fail on invalid certs
              rejectUnauthorized: false
            }
          });
      }
      
      
      var mailOptions = {
        from: req.body.emailInfo.fromName.length > 0 ? '"'+decodeURIComponent(req.body.emailInfo.fromName)+'" <'+decodeURIComponent(req.body.emailInfo.fromEmail)+'>' : decodeURIComponent(req.body.emailInfo.fromEmail),
        to: decodeURIComponent(req.body.emailInfo.to),
        subject: decodeURIComponent(req.body.emailInfo.subject),
        bcc: JSON.parse(decodeURIComponent(req.body.emailInfo.bcc)),
        cc: JSON.parse(decodeURIComponent(req.body.emailInfo.cc)),
        attachments: typeof(req.session['attachments']) != 'undefined' ? req.session['attachments'] : [],
        html: emailTemplate
      };  
      
      transporter.sendMail(mailOptions, function(error, info){
        var msg = !error ? {status: 200, message:'Email sent: ' + info.response} : {status: 400, message: error};
        delete req.session.attachments;
        res.json(msg);
      }); 
    }
  
});

module.exports = router;