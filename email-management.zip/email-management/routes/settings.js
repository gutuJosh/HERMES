var express = require('express');
var router = express.Router();
var fs = require("fs");


router.post('/', function(req, res, next) {

    var errors = '';
 
    if(!req.body.templateName || req.body.templateName === '' || !req.body.language || req.body.language === ''){

        errors = !req.body.templateName || req.body.templateName === '' ? 'template name' : '';
        errors =  !req.body.language || req.body.language === '' ? errors+', language' : errors;
        res.json([{
            status: 400,
            info: errors
          }
          ]);
    
    }
    else{
       var language = decodeURIComponent(req.body.language).substring(0, 2);
       try{
        var initFile = JSON.parse(fs.readFileSync("config/init-"+language+".json"));
       }
       catch(err){
         console.log(err);
         errors += err;
         res.json([{
            status: 400,
            message: errors
          }
          ]);
       }
       
       var fileWasModified = 0;
       for(var key in initFile){
        if(decodeURIComponent(req.body.templateName) === key){
            initFile[key].textBlocks = decodeURIComponent(req.body.textBlocks);
            initFile[key].highlightedTexts = req.body.highlightedTexts !== '' ? JSON.parse(decodeURIComponent(req.body.highlightedTexts)) : '',
            initFile[key].widgets = req.body.widgets !== '' ? JSON.parse(decodeURIComponent(req.body.widgets)) : '',
            initFile[key].firma = decodeURIComponent(req.body.firma);
            initFile[key].fromName = decodeURIComponent(req.body.fromName);
            initFile[key].fromEmail = decodeURIComponent(req.body.fromEmail);
            initFile[key].cc = decodeURIComponent(req.body.cc);
            initFile[key].bcc = decodeURIComponent(req.body.bcc);
            initFile[key].subject = decodeURIComponent(req.body.subject);
            fileWasModified = 1;
            break;
        }
      }

      if(fileWasModified === 1){
        initFile = JSON.stringify(initFile);
        fs.writeFile("config/init-"+language+".json", initFile, function(error) {
            if (error) {
              console.error(error.message);
              errors += error.message;
              res.json([{
                status: 400,
                message: errors
              }
              ]);
            } else {
                res.json([{
                    status: 200,
                    message: "The file" + " config/init-"+language+".json was modified successfully"
                  }
                  ]);
            }
       });
      }
      else{
        res.json([{
            status: 400,
            message: "Template non found"
          }
          ]);
      }
     
    }
   
 });

 
module.exports = router;